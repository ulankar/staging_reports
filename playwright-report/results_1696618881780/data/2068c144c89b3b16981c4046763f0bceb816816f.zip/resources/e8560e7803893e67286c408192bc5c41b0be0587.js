AngularBackend.registerCtrl('OrderModerationFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {
    
    $scope.disabledPaymentButton = true;
    
    var fieldsId = $scope.getFieldsId($scope.view);
    $scope.$watch('item[' + $scope.field.id + '].statusId', function() {
        $.each($scope.view.fields, function (i, el) {
            if (el.fieldName == $scope.field.rFormField) {
                $scope.item[i] = $scope.item[$scope.field.id].statusId;
            }
        });
    });

    $scope.$watch('item[' + $scope.field.id + '].paymentStatusId', function(newVal) {
        $scope.item[fieldsId.paymentStatusId] = newVal;
    });

    $scope.toggleDisablePayment = function () {
        if($scope.disabledPaymentButton) {
            $uibModal.open({
                templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
                controller: 'ModalWindowCtrl',
                size: 'sm',
                resolve: {
                    params: function () {
                        return {
                            'msg': ' Are you really want to change Payment status ?',
                            'title': 'Attention!'
                        };
                    }
                }
            }).result.then(function () {
                $scope.disabledPaymentButton = false;
            });
        } else {
            $scope.disabledPaymentButton = true;
        }
    };
});