AngularBackend.registerCtrl('RolePermissionsController', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification)
{
    $scope.item[$scope.field.id] = ($scope.item[$scope.field.id]) ? $scope.item[$scope.field.id] : $scope.field.dataSource;
    $scope.checking = "Check All";

    $scope.checkUncheckAll = function () {
        for(var i = 0 ; i < $scope.item[$scope.field.id].length ; i++)
        {
            $scope.item[$scope.field.id][i].access =
                $scope.item[$scope.field.id][i].delete =
                    $scope.item[$scope.field.id][i].write =
                        $scope.item[$scope.field.id][i].read = ($scope.checking == "Check All") ? '1' : '0';
        }
        $scope.checking = ($scope.checking == "Check All") ? "Uncheck All" : "Check All";
    };

    $scope.checkedParent = function(index, itemId, action)
    {
        for(var i = 0 ; i < $scope.item[$scope.field.id].length ; i++) {
            if ($scope.item[$scope.field.id][i]['parentId'] == itemId)
            {
                $scope.item[$scope.field.id][i][action] = $scope.item[$scope.field.id][index][action];
            }
        }
    };

    $scope.filterParents = function (el) {
        return el.parentId == 0 || el.parentId == null;
    };
});