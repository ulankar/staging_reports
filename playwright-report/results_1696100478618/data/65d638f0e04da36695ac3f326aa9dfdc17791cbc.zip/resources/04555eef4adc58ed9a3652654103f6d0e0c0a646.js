AngularBackend.registerCtrl('HTMLEditorFieldCtrl', function ($scope, $http, $state, $location, $stateParams, $compile, $rootScope, items, Notification, $uibModal, $timeout) {
    $scope.tinymceOptions = {
        // Update model when calling setContent (such as from the source editor popup)
        plugins: [
            "advlist autolink lists link image charmap print preview anchor pagebreak",
            "searchreplace visualblocks code fullscreen wordcount visualchars",
            "insertdatetime media table contextmenu imagetools",
            "nonbreaking save directionality",
            "emoticons template paste textcolor colorpicker textpattern codemirror",
        ],
        valid_elements: "*[*]",
        verify_html : false,
        media_strict: false,

        // Google says pasteword not working in tinymce after 4.0
        toolbar1: "  code | undo redo | styleselect | forecolor backcolor bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image media | fullscreen",
        max_height: 370,
        min_height: 180,
        height: 280,
        menubar: true,
        relative_urls: false,
        remove_script_host: false,
        toolbar_items_size: 'small',
        link_class_list: [
            {title: 'None', value: ''},
            {title: 'Orange Button', value: 'orange-btn'},
            {title: 'Red Button', value: 'red-btn'},
            {title: 'Red Button Nav', value: 'red-btn-nav'}
        ],
        forced_root_block: "",
        force_p_newlines: true,
        force_br_newlines: false,
        content_css: $scope.field.dataSource,
        codemirror: {
            indentOnInit: true, // Whether or not to indent code on init.
            path: 'CodeMirror', // Path to CodeMirror distribution
            config: {           // CodeMirror config object
                mode: 'htmlmixed',
                lineNumbers: true,
                extraKeys: {
                    "F11": function (cm) {
                        cm.setOption("fullScreen", !cm.getOption("fullScreen"));
                    },
                    "Esc": function (cm) {
                        if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
                    }
                },
                theme: "neo"
            },
            jsFiles: [          // Additional JS files to load
                'lib/codemirror.js',
                'mode/xml/xml.js',
                'mode/clike/clike.js',
                'mode/htmlmixed/htmlmixed.js',
                'addon/display/fullscreen.js'
            ],
            cssFiles: [
                'lib/codemirror.css',
                'addon/display/fullscreen.css',
                'theme/neo.css'
            ]
        },
        file_browser_callback: function (field, url, type, win) {
            switch (type) {
                case 'file':
                    $scope.showLinkView(field);
                    break;
                case 'image':
                    tinyMCE.activeEditor.windowManager.open({
                        file: '/backend/webcontent/kcfinder/browse.php?opener=tinymce4&field=' + field + '&type=images',
                        title: 'KCFinder',
                        width: 700,
                        height: 500,
                        inline: true,
                        close_previous: false
                    }, {
                        window: win,
                        input: field
                    });
                    return false;
                    break;
            }
        },
        //DO NOT REMOVE! NEED FOR EVENT AUTO-REPLACE!!!
        setup: function(ed) {
            var args;
            ed.on('focus', function (e) {
                $scope.setFocusedItem('tinymce', tinymce);
            });
        },
        elements: $scope.field.id
    };

    $scope.showLinkView = function (field) {
        $('.mce-container.mce-panel.mce-window.mce-in').css('z-index', '1001');
        $rootScope.loading = true;
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: 1,
                    displayMode: 1
                }
            }
        }).result.then(function (itemData) {
                var data = {
                    controller: "FieldController",
                    method: "getPageUrl",
                    pageParams: itemData.item,
                    viewId: itemData.viewId
                };

                $.post('index.php', data, function (result) {
                    $timeout(function () {
                        if (result.success) {
                            document.getElementById(field).value = result.url;
                        }
                        $rootScope.loading = false;
                    });
                }, 'json');
            });
    };
});