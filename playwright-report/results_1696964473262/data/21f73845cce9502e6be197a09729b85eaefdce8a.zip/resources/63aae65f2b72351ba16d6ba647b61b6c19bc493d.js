AngularBackend.registerCtrl('TextAreaFieldCntrl', function ($scope, $http, $state, $location, $stateParams, $compile, $rootScope, Notification, $timeout, $uibModal) {
    $scope.initField = function () {
        $scope.$watch('item[' + $scope.field.id + ']', function (newValue, oldValue) {
            if (typeof newValue == 'undefined')
                return;

            if(!$scope.field.maxLength)
                 return;

            if ($scope.field.maxLength - newValue.length < 0)
            {
                $scope.item[$scope.field.id] = newValue.substr(0, $scope.field.maxLength);
            }
        });
    };
});