AngularBackend.registerCtrl('ProductOptionsFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {
    $scope.elements = [];

    $scope.IDFieldId = 0;
    $scope.displayField = '';
    $scope.searchFieldId = 0;
    $scope.priceIdField = 0;
    $scope.priceTypeId = 0;

    $scope.ConfigurationTypes = {
        Option: 1,
        Product: 2
    };

    $.each($scope.field.dataSource.fields, function (fieldId, field) {
        $.each($scope.field.dataSource.primaryKeys, function (keyId, keyValue) {
            if (keyId == fieldId)
                $scope.IDFieldId = fieldId;
        });
        if (field.fieldName == 'value')
            $scope.displayField = fieldId;

        if (field.fieldName == 'optionId')
            $scope.searchFieldId = fieldId;

        if (field.fieldName == 'price')
            $scope.priceIdField = fieldId;

        if (field.fieldName == 'priceTypeId')
            $scope.priceTypeId = fieldId;
    });

    $scope.initField = function ()    {
        $scope.getElements();
    };

    $scope.getElements = function()
    {
        var data = {
            controller: "ProductOptionsField",
            method: "GetElements",
            itemId: $stateParams.itemId
        };

        $.post('index.php', data, function (result) {
            if (result.success) {
                $timeout(function () {
                    $scope.elements = result.items;
                    $rootScope.options = $scope.elements;
                });
            }
        }, 'json');
    };

    $scope.field.saveFieldData = function (itemId) {
        var params = {};

        $.each($scope.elements, function (elId, element) {
            params[elId] = element.values;
        });

        var val = {
            controller: "ProductOptionsField",
            method: "SaveElements",
            viewId: $scope.view.id,
            itemId: itemId,
            fieldId: $scope.field.id,
            data: params
        };

        $.post('index.php', val, function (result) {
            if (result.success) {

            }
        }, 'json');
    };

    $scope.addItem = function () {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.defaultValue,
                    displayMode: 2
                }
            }
        }).result.then(function (itemData) {
                if(itemData == undefined)
                    return;

                    var data = {
                        controller: "ProductOptionsField",
                        method: "GetElement",
                        //item: itemData.item,
                        items:  itemData.selected,
                        viewId: $scope.field.defaultValue,
                        dataSourceId: $scope.view.id,
                        fieldId: $scope.field.id
                    };

                    $.post('index.php', data, function (result) {
                        if (result.success)
                        {
                            $timeout(function () {
                                if (!Object.keys($scope.elements).length)
                                    $scope.elements = {};

                                var addedOptionsStr = "";
                                var existOptionsStr = "";
                                $.each(result.elements, function(elementId, element) {

                                    if ($scope.elements[elementId] == undefined) {
                                        $scope.elements[elementId] = element;
                                        addedOptionsStr += $scope.elements[elementId].title + "<br>";
                                    }
                                    else {
                                        if ($scope.elements[elementId].visible)
                                            existOptionsStr += $scope.elements[elementId].title + "<br>";

                                        $scope.elements[elementId].visible = true;
                                    }
                                });

                                if(addedOptionsStr != "")
                                    Notification.success('<b>Options:</b> <br>' + addedOptionsStr + ' <b>was added!</b>');

                                if(existOptionsStr != "")
                                    Notification.info('<b>Options:</b> <br>' + existOptionsStr + ' existing in list of attributes!');
                            });

                            $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                        }
                    }, 'json');
            }, function(){
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            });
    };

    $scope.changeElementPrice = function(item){
        if(item.priceTypeId == 2)
        {
            var productFields = $scope.getFieldsId($scope.view);
            var productPrice = $scope.item[productFields['price']];
            item.totalPrice = (productPrice * item.price / 100).toFixed(2);
            item.amount = 1;
        }
        else
        {
            item.totalPrice = (item.price * item.amount).toFixed(2);
        }
    };

    $scope.changeElementTotalPrice = function(item){
        item.price = (item.totalPrice / item.amount).toFixed(2);
    };

    $scope.addConfigurationItem = function (elementId) {
        $scope.search = {};
        $scope.search[$scope.searchFieldId] = elementId;

        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.dataSource.id,
                    displayMode: 2,
                    search: $scope.search
                }
            }
        }).result.then(function (itemData)
            {
                if(itemData == undefined)
                    return;

                if ($scope.elements[elementId].values == undefined || $scope.elements[elementId].values == null)
                    $scope.elements[elementId].values = [];

                $.each(itemData.selected, function(index, element){
                    if ($.grep($scope.elements[elementId].values, function (n)
                        {
                            return n.id != element[$scope.IDFieldId];
                        }).length == $scope.elements[elementId].values.length) {

                        var item = {};
                        item.id = element[$scope.IDFieldId];
                        item.value = element[$scope.displayField];
                        item.type = $scope.ConfigurationTypes.Option;
                        item.basePrice = element[$scope.priceIdField];
                        item.price = item.basePrice;
                        item.priceTypeId = element[$scope.priceTypeId];
                        item.amount = 1;
                        item.totalPrice = (item.amount * item.price).toFixed(2);

                        $scope.changeElementPrice(item);
                        $scope.elements[elementId].values.push(item);
                    }
                });

                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;

            },function(){
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            });
    };


    $scope.productIDFieldId = 0;
    $scope.productDisplayField = '';
    $scope.productPriceFieldId = 0;

    $.each($scope.view.fields, function (fieldId, field) {
        $.each($scope.view.primaryKeys, function (keyId, keyValue) {
            if (keyId == fieldId)
                $scope.productIDFieldId = fieldId;
        });
        if (field.fieldName == 'title')
            $scope.productDisplayField = fieldId;

       if (field.fieldName == 'price')
           $scope.productPriceFieldId = fieldId;
    });

    $scope.addProductItem = function (elementId) {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.view.id,
                    displayMode: 2
                }
            }
        }).result.then(function (itemData)
            {
                if(itemData == undefined)
                    return;

                if ($scope.elements[elementId].values == undefined)
                    $scope.elements[elementId].values = [];

                $.each(itemData.selected, function(index, element) {
                    if ($.grep($scope.elements[elementId].values, function (n) {
                            return n.id != element[$scope.productIDFieldId];
                        }).length == $scope.elements[elementId].values.length) {

                        var item = {};
                        item.id = element[$scope.productIDFieldId];
                        item.value = element[$scope.productDisplayField];
                        item.type = $scope.ConfigurationTypes.Product;
                        item.basePrice = element[$scope.productPriceFieldId];
                        item.price = item.basePrice;
                        item.priceTypeId = '1';
                        item.amount = 1;
                        item.totalPrice = (item.amount * item.price).toFixed(2);

                        $scope.elements[elementId].values.push(item);
                    }
                });

                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            }, function(){
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            });
    };

    $scope.deleteConfiguration = function(elementId)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete configuration "' + $scope.elements[elementId].title + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {

                $scope.elements[elementId].values = [];
                $scope.elements[elementId].visible = false;

                Notification.info('Configuration "' + $scope.elements[elementId].title + '" was deleted!');

            });
    };

    $scope.deleteConfigurationItem = function(element, i)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete value for configuration "' + element.title + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function(){
                /*delete element.values[i.id + '_' + i.type];*/
                    $.each(element.values, function(index)
                    {
                        if(this.id == i.id)
                            element.values.splice(index, 1);
                    })
            });
    };
});