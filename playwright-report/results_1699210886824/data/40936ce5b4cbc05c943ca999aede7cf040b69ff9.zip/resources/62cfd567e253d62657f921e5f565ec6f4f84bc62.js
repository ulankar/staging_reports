AngularBackend.registerCtrl('AutoTitleFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {

    $scope.field.validateField = function(_callback){
        if($scope.item[$scope.field.id].settings.change && $scope.field.availableValues == '1' && $scope.item[$scope.field.id].settings.useMask) {
            $uibModal.open({
                templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
                controller: 'ModalWindowCtrl',
                size: 'sm',
                resolve: {
                    params: function () {
                        return {
                            'msg': 'Are you sure save mask and run task?',
                            'title': 'Please, confirm action'
                        };
                    }
                }
            }).result.then(function () {
                    _callback(false);
                }, function () {
                    _callback(true);
                });
        }
        else
        {
            _callback(false);
        }
    };

    $scope.allowTitleChanging = true;

    if($scope.item[$scope.field.id]&& $scope.item[$scope.field.id].settings && $scope.item[$scope.field.id].settings.useMask)
        $scope.allowTitleChanging = $scope.item[$scope.field.id].settings.useMask == 1;

    if($scope.item[$scope.field.id] == undefined)
        $scope.item[$scope.field.id] = $scope.field.defaultValue;

    $scope.subscribeFieldId = 0;
    $.each($scope.view.fields, function (i, el) {
        if (el.fieldName == $scope.field.rFormField) {
            $scope.subscribeFieldId = el.id;
            el.readonly = $stateParams.itemId == '';
        }
    });

    $scope.rFieldNameId = 0;
    if ($scope.field.rFieldName != "" && $scope.field.rFormField != undefined) {
        $.each($scope.view.fields, function (i, el) {
            if (el.fieldName == $scope.field.rFieldName) {
                $scope.rFieldNameId = el.id;
                $scope.$watch('item[' + el.id + ']', function (fieldValue) {
                    $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
                });
            }
        });
    }

    $scope.onDragEnd = function () {
        $.each($scope.item[$scope.field.id].items, function(i) {
            $scope.item[$scope.field.id].items[i].order = i + 1;
        });
        $scope.item[$scope.field.id].settings.change = 1;

        $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
    };

    $scope.rSourcePointerFieldId = 0;
    if ($scope.field.rSourcePointerField != "" && $scope.field.rSourcePointerField != undefined) {
        $.each($scope.view.fields, function (i, el) {
            if (el.fieldName == $scope.field.rSourcePointerField) {
                $scope.rSourcePointerFieldId = el.id;
                $scope.$watch('item[' + el.id + ']', function (newValue, oldValue) {
                    if(newValue == oldValue) return;
                    var data = {
                        controller: "AutoTitleField",
                        method: "getFunctionalName",
                        functionalNameId: newValue
                    };

                    $.post('index.php', data, function (result) {
                        if (result.success) {
                            $timeout(function () {
                                $scope.item[$scope.field.id] = result.items;
                                $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
                            });
                        }
                    }, 'json');

                });
            }
        });
    }

    $scope.addItem = function()
    {
        $uibModal.open({
            templateUrl: 'AutoTitlePopUp',
            controller: function($scope, $modalInstance){
                $scope.selectMask = function(mask)
                {
                    $modalInstance.close(mask);
                };
            },
            scope: $scope
        }).result.then(function(mask)
            {
                if(!$scope.item[$scope.field.id])
                    $scope.item[$scope.field.id] = {};

                if(!$scope.item[$scope.field.id].items)
                    $scope.item[$scope.field.id].items = [];

                if ($.grep($scope.item[$scope.field.id].items, function (n){return n.id != mask.id;}).length == $scope.item[$scope.field.id].items.length) {
                    $scope.item[$scope.field.id].items.push(mask);
                    $scope.item[$scope.field.id].settings.change = 1;
                    $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
                    Notification.info('Mask "' + mask.value + '" was added!');
                }
                else
                {
                    Notification.info('Mask "' + mask.value + '" already exist!');
                }

            });
    };

    $scope.changeMask = function (items, attributes) {
        $scope.textMask = '';
        $.each(items, function (index, element) {
            if (element.type == 1) {

                switch(element.id)
                {
                    case '100000000001':
                        $.each($scope.view.fields[$scope.rFieldNameId].dataSource, function (index, val) {
                            if (val.id == $scope.item[$scope.rFieldNameId]) {
                                $scope.textMask += ' ' + val.title;
                            }
                        });
                        break;

                    case '100000000002':
                        $.each($scope.view.fields[$scope.rSourcePointerFieldId].dataSource, function (index, val) {
                            if (val.id == $scope.item[$scope.rSourcePointerFieldId]) {
                                $scope.textMask += ' ' + val.title;
                            }
                        });
                        break;
                }
            }

            if (element.type == 2) {
                if (attributes) {
                    $.each(attributes, function (id, el) {
                        if (id == element.attributeId)
                        {
                            $.each(el.values, function(iV, v){
                                if(el.values[iV].value) {
                                    $scope.textMask += ' ' + el.values[iV].value;
                                    if(el.measureTitle)
                                        $scope.textMask += ' ' + el.measureTitle;
                                }
                            });
                        }
                    });
                }
            }
        });

        $scope.textMask = $scope.textMask.trim().charAt(0).toUpperCase() + $scope.textMask.trim().toLowerCase().slice(1);

        if($scope.allowTitleChanging)
        {
            $scope.item[$scope.subscribeFieldId] = $scope.textMask;
        }
        // $scope.initDragular();
    };

    $scope.toggleSorting = function()
    {
        if($scope.allowTitleChanging) {
            $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);

            Notification.info('Auto title changing enable');
        } else {
            Notification.info('Auto title changing disable');
        }

        $scope.item[$scope.field.id].settings.change = 1;
        $scope.item[$scope.field.id].settings.useMask = $scope.allowTitleChanging ? 1 : 0;

        $scope.view.fields[$scope.subscribeFieldId].readonly = false;
    };

    $scope.$on('attributeChangeEvent', function (event, data) {
        $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
    });

    $scope.deleteItem = function(mask)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete mask "' + mask.value + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {
                var index = $scope.item[$scope.field.id].items.indexOf(mask);
                $scope.item[$scope.field.id].items.splice(index, 1);
                $scope.item[$scope.field.id].settings.change = 1;

                $scope.changeMask($scope.item[$scope.field.id].items, $scope.attributes);
                Notification.info('mask "' + mask.value + '" was deleted!');
            });
    };
});