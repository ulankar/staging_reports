AngularBackend.registerCtrl('MultiSelectFieldCtrl', function ($scope, $uibModal, $timeout, $rootScope, $stateParams, Notification)
{
    $scope.search = {};
    $scope.selectedOptions = [];
    $scope.newAttribute = {};
    $scope.newAttribute.value = '';

    $scope.itemIdFieldId = 0;
    $scope.IDFieldId = 0;
    $scope.displayField = '';

    $scope.subscribeFieldId = 0;
    $.each($scope.view.fields, function (i, el) {

        if (el.fieldName == $scope.field.rFormField) {
            $scope.$watch('item[' + el.id + ']', function (fieldValue) {
                switch(el.fieldTypeId) {
                    case '6':
                        if(el.displayType == '2') {
                            $scope.field.visible = !!+fieldValue;
                        }
                        break;

                    default:
                        var array = $scope.field.availableValues.split(',');

                        if(typeof array == 'object') {
                            $scope.field.visible = array.indexOf(fieldValue) >= 0;
                        }
                        else {
                            $scope.field.visible = fieldValue == $scope.field.availableValues;
                        }

                        if(!$scope.field.visible)
                            $scope.item[$scope.field.id] = {};
                }
            });
        }
    });

    $.each($scope.view.fields, function(fieldId, field){
        $.each($scope.view.primaryKeys, function(keyId, keyValue){
            if(keyId == fieldId)
                $scope.itemIdFieldId = fieldId;
        });
    });

    $.each($scope.field.dataSource.fields, function(fieldId, field){
        $.each($scope.field.dataSource.primaryKeys, function(keyId, keyValue){
            if(keyId == fieldId)
                $scope.IDFieldId = fieldId;
        });
        if(field.fieldName == $scope.field.rDisplayFields)
            $scope.displayField = fieldId;
    });

    $scope.searchFieldId = 0;
    $.each($scope.field.dataSource.fields, function (fieldId, field) {
        if (field.fieldName == $scope.field.rFieldName)
            $scope.searchFieldId = fieldId;
    });

    $scope.rSourcePointerFieldId = 0;
    $.each($scope.field.dataSource.fields, function (fieldId, field) {
        if (field.fieldName == $scope.field.rSourcePointerField && !field.isComplexField)
            $scope.rSourcePointerFieldId = fieldId;
    });

    if($scope.item[$scope.field.id] == undefined)
    {
        $scope.item[$scope.field.id] = {};
    }
    if($scope.item[$scope.field.id].items == undefined)
    {
        $scope.item[$scope.field.id].items = [];
    }

    $scope.addItem = function()
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.dataSource.id,
                    displayMode: 1
                }
            }
        }).result.then(function(itemData) {
            if($.grep($scope.item[$scope.field.id].items, function(n) { return n[$scope.IDFieldId] != itemData.item[$scope.IDFieldId]; }).length == $scope.item[$scope.field.id].items.length) {
                $scope.item[$scope.field.id].items.push(itemData.item);
            }
                $rootScope.loading = false;
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
        }, function(){
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                $rootScope.loading = false;
            });
    };

    $scope.labelDeviceAutoComplete = {
        source: function (request, response) {
            var array = [];

            // $scope.search[$scope.displayField] = request.term + '*';
            $scope.search[$scope.displayField] = request.term;

                var data = {
                    controller: "ViewController",
                    method: "buildList",
                    countOnPage: 20,
                    currentPage: 0,
                    orderField: '',
                    orderMethod: '',
                    viewId: $scope.field.dataSource.id,
                    params: $scope.search
                };

                $.post('index.php', data, function (result) {
                    if (result.success) {
                        $timeout(function () {
                            $.each(result.view.items, function(a, b)
                            {
                                array.push(b);
                            });

                            response(array);
                        });
                    }
                }, 'json');
        },
        minLength: 2,
        select: function (event, ui)
        {
            this.value = ui.item[$scope.displayField];
            $timeout(function()
            {
                if($.grep($scope.item[$scope.field.id].items, function(n) { return n[$scope.IDFieldId] != ui.item[$scope.IDFieldId]; }).length == $scope.item[$scope.field.id].items.length)
                {
                    $scope.item[$scope.field.id].items.push(ui.item);
                }
            });
            this.value = '';
            return false;
        },

        _renderItem:  function (ul, item)
        {
            return $("<li>").data("item.autocomplete", item)
                            .append("<a>" + item[$scope.displayField] + "</a>")
                            .appendTo(ul);
        },

        focus: function(event, ui)
        {
            $timeout(function(){
                $scope.autoCompleteItem = ui.item[$scope.displayField];
            });
        }
    };

    $scope.deleteItem = function()
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete attribute values ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {
                //delete from js model
                if ($scope.item[$scope.itemIdFieldId] == undefined)
                {
                    $.each($scope.selectedOptions, function () {
                        var selected = this;
                        $.each($scope.item[$scope.field.id].items, function (index) {
                            if ($scope.item[$scope.field.id].items[index] == selected) {
                                $scope.item[$scope.field.id].items.splice(index, 1);
                            }
                        });
                    });
                }
                else {
                    $.each($scope.selectedOptions, function () {
                        var selected = this;
                        $.each($scope.item[$scope.field.id].items, function (index) {
                            //if filedId
                            if (this[$scope.IDFieldId] == selected[$scope.IDFieldId]) {
                                $scope.item[$scope.field.id].items.splice(index, 1);
                                $scope.item[$scope.field.id].deleted.push(this);
                            }
                        })
                    });
                }

                Notification.info('Attribute values was deleted!');

            });
    };

    $scope.addNewValue = function() {
        $scope.search = {};
        $scope.search[$scope.searchFieldId] = $stateParams.itemId;

        if ($scope.item[$scope.itemIdFieldId] == undefined)
        {
            $uibModal.open({
                templateUrl: '/backend/webcontent/templates/pages/item.html',
                controller: 'ItemCtrl',
                size: 'lg',
                scope: $scope,
                resolve: {
                    $stateParams: {
                        view: $scope.field.dataSource,
                        item: {},
                        DisplayMode: 2
                    }
                }
            }).result.then(function (itemData) {
                    $scope.item[$scope.field.id].items = $scope.item[$scope.field.id].items || [];

                    $scope.item[$scope.field.id].items.push(itemData.item);
                    $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                    $rootScope.loading = false;
                }, function(){
                    $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                    $rootScope.loading = false;
                });
        }
        else
        {
            $uibModal.open({
                templateUrl: '/backend/webcontent/templates/pages/list.html',
                controller: 'ListCtrl',
                size: 'lg',
                scope: $scope,
                resolve: {
                    $stateParams: {
                        viewId: $scope.field.rSearchViewId,
                        displayMode: 1,
                        search: $scope.search
                    }
                }
            }).result.then(function (itemData) {
                    $scope.item[$scope.field.id].items = $scope.item[$scope.field.id].items || [];
                
                    if ($.grep($scope.item[$scope.field.id].items, function (n) {
                            return n[$scope.rSourcePointerFieldId] != itemData.item[$scope.rSourcePointerFieldId];
                        }).length == $scope.item[$scope.field.id].items.length) {

                        $scope.item[$scope.field.id].items.push(itemData.item);
                    }
                    else {
                        Notification.info('Value already exist!');
                    }
                    $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                    $rootScope.loading = false;
                }, function(){
                    $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                    $rootScope.loading = false;
                });
        }
    };

    $scope.editItem = function(displayType)
    {
        var stateParams;

        if(displayType == 3) {
            stateParams = {
                viewId: $scope.selectedOptions[0].viewId,
                itemId: $scope.selectedOptions[0].itemId,
                DisplayMode: $rootScope.DisplayActionsModes.PopUp
            };
        }
        else {
            if($scope.selectedOptions[0][$scope.itemIdFieldId] == undefined) {
                stateParams = {
                    view: $scope.field.dataSource,
                    item: $scope.selectedOptions[0],
                    DisplayMode: $rootScope.DisplayActionsModes.PopUpWithOutSave
                };
            }
            else {
                stateParams = {
                    viewId: $scope.field.rSearchViewId,
                    item: $scope.selectedOptions[0],
                    DisplayMode: $rootScope.DisplayActionsModes.PopUp
                };
            }
        }

        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/item.html',
            controller: 'ItemCtrl',
            size: 'lg',
            /*scope: $scope,*/
            resolve: {
                $stateParams: stateParams
            }
        }).result.then(function (itemData) {
            if(displayType != 3) {
                if(itemData) {
                    $.each($scope.item[$scope.field.id].items, function (index, item) {
                        if (item[$scope.rSourcePointerFieldId] == $scope.selectedOptions[0][$scope.rSourcePointerFieldId]) {
                            $scope.item[$scope.field.id].items[index] = itemData.item;
                        }
                    });
                }
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                // $rootScope.loading = false;
            }
            $rootScope.loading = false;
        }, function(){
            $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            $rootScope.loading = false;
        });
    };

    $scope.moveUp = function()
    {
        var new_index = 0;
        var old_index = 0;
        $.each($scope.item[$scope.field.id].items, function(index, item) {
            if($scope.selectedOptions[0][$scope.displayField] == item[$scope.displayField])
            {
                old_index = index;
                new_index = old_index - 1;
            }
        });

        if (new_index >= 0)
            $scope.item[$scope.field.id].items.splice(new_index, 0, $scope.item[$scope.field.id].items.splice(old_index, 1)[0]);
    };

    $scope.moveDown = function()
    {
        var new_index = 0;
        var old_index = 0;
        $.each($scope.item[$scope.field.id].items, function(index, item) {
            if($scope.selectedOptions[0][$scope.displayField] == item[$scope.displayField])
            {
                old_index = index;
                new_index = old_index + 1;
            }
        });

        if (new_index < $scope.item[$scope.field.id].items.length)
            $scope.item[$scope.field.id].items.splice(new_index, 0, $scope.item[$scope.field.id].items.splice(old_index, 1)[0]);
    };

    $scope.$watchCollection('selectedOptions', function(){
        if($scope.newAttribute.index != undefined)
        {
            $scope.selectedOptions = [];
            $scope.newAttribute = {};
            $scope.newAttribute.value = '';
        }
    });
});