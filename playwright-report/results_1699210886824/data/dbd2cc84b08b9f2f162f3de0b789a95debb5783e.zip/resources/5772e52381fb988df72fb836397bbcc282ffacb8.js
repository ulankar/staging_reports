AngularBackend.registerCtrl('LocationFieldCtrl', function ($scope, $compile, $timeout, $uibModal, Notification)
{
    //region [Variables]

    $scope.item[$scope.field.id] = {};
    $scope.map = {};
    $scope.marker = {};
    $scope.geocoder = {};
    $scope.relatedFields = {};
    $scope.item[$scope.field.id].relatedFieldsValues = [{}];
    $scope.item[$scope.field.id].coordinates = {lat: 50.969, lng: 4.1806};

    //endregion

    //region [Initialize field]

    $scope.initLocationField = function () {
        if (typeof google != 'undefined')
        {
            $scope.initMap();
            $scope.initRelatedFields();
        }
        else
        {
            $scope.field.visible = false;
        }
    };

    //endregion

    //region [Google Map]

    $scope.initMap = function () {
        $scope.initMapObject();
        $scope.initMarker();
        $scope.initAutocomplete();
        $scope.geocoder = new google.maps.Geocoder();
    };

    $scope.initMapObject = function () {
        var mapOptions = {
            center: new google.maps.LatLng($scope.item[$scope.field.id].coordinates.lat,
                $scope.item[$scope.field.id].coordinates.lng),
            zoom: 12,
            scrollwheel: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            disableDefaultUI: true
        };
        $scope.map = new google.maps.Map(document.getElementById('google-map'), mapOptions);
    };

    $scope.initMarker = function () {
        $scope.marker = new google.maps.Marker({
            map: $scope.map,
            draggable: true,
            animation: google.maps.Animation.DROP,
            position: new google.maps.LatLng($scope.item[$scope.field.id].coordinates.lat,
                $scope.item[$scope.field.id].coordinates.lng)
        });
        $scope.map.setCenter($scope.marker.getPosition());

        google.maps.event.addListener($scope.marker, 'dragend', function(evt)
        {
            $scope.setCoordinates($scope.marker.getPosition().lat(), $scope.marker.getPosition().lng());
        });
    };

    $scope.initAutocomplete = function () {
        var cityAutocomplete = new google.maps.places.Autocomplete(document.getElementById('cityInput'), {types: ['(cities)']});
        var streetAutocomplete = new google.maps.places.Autocomplete( document.getElementById('streetInput'));

        cityAutocomplete.addListener('place_changed', function() {
            $('#cityInput').trigger('change');
        });
        streetAutocomplete.addListener('place_changed', function() {
            $('#streetInput').trigger('change');
        });
    };

    //region [rePaint map on tab changed]
    $scope.$watch('$parent.selectedTab', function () {
        $timeout(function () {
            google.maps.event.trigger($scope.map, 'resize');
            $scope.map.setCenter($scope.marker.getPosition());
        });
    });
    //endregion

    //endregion

    //region [Related fields]

    $scope.initRelatedFields = function(){
        var rFields = $scope.field.rFormField.split(",");
        for( var i = 0 ; i < rFields.length ; i++)
        {
            var keyValueField = rFields[i].split("=>");
            $scope.relatedFields[keyValueField[0]] = keyValueField[1];
            if($scope.field.dataSource && $scope.field.dataSource[0])
                $scope.item[$scope.field.id].relatedFieldsValues[0][keyValueField[1]] = $scope.field.dataSource[0][keyValueField[1]];
        }
        if($scope.field.dataSource && $scope.field.dataSource[0])
        {
            $timeout(function(){
                var loc = $scope.field.dataSource[0]['location'].split(',');
                $scope.setCoordinates(loc[0], loc[1]);
                $scope.rewriteMarker();
            });
        }
    };

    //endregion

    //region [Work with position and address]

    //region [Address]

    $scope.findAddress = function () {
        $scope.geocoder.geocode({'location': $scope.item[$scope.field.id].coordinates}, function (results, status) {
            if (status === google.maps.GeocoderStatus.OK) {
                if (results[1]) {
                    $scope.buildAddress(results[1].address_components);
                }
            }
            else{
                Notification.error({title: 'Error', message: 'Not founded location info'});
            }
        });
    };
    
    $scope.buildAddress = function (positionInfo) {
        $timeout(function(){
            var flagBuilded = false;
            for (var i = 0 ; i < positionInfo.length ; i++){
                switch (positionInfo[i].types[0])
                {
                    case 'route':
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.street] = positionInfo[i].long_name;
                        break;
                    case 'locality':
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.city] = positionInfo[i].long_name;
                        flagBuilded = true;
                        break;
                    case 'street_number':
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.house_num] = positionInfo[i].long_name;
                        break;
                }
            }
            if(!flagBuilded)
            {
                Notification.error({title: 'Error', message: 'Not founded location info'});
            }
        });
    };

    $scope.toNormalForm = function (fieldName) {
        var fieldKey = $scope.relatedFields[fieldName];
        if($scope.item[$scope.field.id].relatedFieldsValues[0][fieldKey] && /,/i.test($scope.item[$scope.field.id].relatedFieldsValues[0][fieldKey]))
        {
            $scope.item[$scope.field.id].relatedFieldsValues[0][fieldKey] = $scope.item[$scope.field.id].relatedFieldsValues[0][fieldKey].split(',')[0];
        }
    };

    //endregion

    //region [Position]

    $scope.buildPosition = function(){
        $scope.geocoder.geocode(
            {'address':
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.street] + ' ' +
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.house_num] + ', ' +
                        $scope.item[$scope.field.id].relatedFieldsValues[0][$scope.relatedFields.city]},
            function (results, status)
            {
                if (status === google.maps.GeocoderStatus.OK)
                {
                    $scope.map.setCenter(results[0].geometry.location);
                    $scope.marker.setPosition(results[0].geometry.location);
                    $scope.setCoordinates($scope.marker.getPosition().lat(), $scope.marker.getPosition().lng());
                }
        });
    };

    $scope.rewriteMarker = function () {
        $scope.marker.setPosition(new google.maps.LatLng($scope.item[$scope.field.id].coordinates.lat,
                                                         $scope.item[$scope.field.id].coordinates.lng));
        $scope.map.setCenter($scope.marker.getPosition());
    };

    $scope.setCoordinates = function (lat, lng) {
        $timeout(function () {
            $scope.item[$scope.field.id].coordinates.lat = parseFloat(lat);
            $scope.item[$scope.field.id].coordinates.lng = parseFloat(lng);
        });
    };
    //endregion

    //endregion

});