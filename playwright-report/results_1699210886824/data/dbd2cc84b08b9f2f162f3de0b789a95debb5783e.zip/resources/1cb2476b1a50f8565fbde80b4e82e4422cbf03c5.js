AngularBackend.registerCtrl('TextFieldCntrl', function ($scope, $http, $state, $location, $stateParams, $compile, $timeout, $rootScope, Notification, $timeout, $uibModal) {
    /*
     * -DESCRIPTION-
     *  Controller work with field, in which displayType=2
     *
     *  rFormField - field, which MUST have name with related field
     *  if rFormField is empty, you will have critical ERRORS
     */

    //console.log($rootScope);
    $scope.field.validateField = function(__callback){
        if(typeof __callback == 'function')
            __callback($scope.field.required == "1" && (typeof $scope.item[$scope.field.id] === 'undefined' || $scope.item[$scope.field.id] == '' ));
    };

    $scope.disabled = {
        btn: 0,
        input: 0
    };
    $scope.unlocked = 0;

    var data = {
        controller: "ViewController",
        method: "getTransliterateText",
        text2Transliterate: ''
    };
    var inputChangedPromise;

    var fieldsId = $scope.getFieldsId($scope.view);

    $scope.initField = function () {
        if ($scope.field.displayType == "2") {
            if ($scope.field.rFormField == "" || typeof $scope.field.rFormField == "undefined") {
                $scope.disabled.btn = 1;
                $scope.disabled.input = 1;
                Notification.error({
                    title: "Error",
                    message: "For fields with displayType=2 You must to fill rFormField"
                });

                return;
            }

            if ($stateParams.isCopyItem) {
                Notification.info("For copying the url code is removed.");
                $scope.item[fieldsId['urlCode']] = "";
            }

            //additional rules for publishing
            if (!!+$scope.view.publishingAllow) {
                if (!!+$scope.item[$scope.fieldsId['visible']] || !$stateParams.itemId || $scope.item[$scope.field.id] != '' || $scope.item[$scope.field.id] != null) {
                    $scope.disabled.input = 1;
                } else if (!+$scope.item[$scope.fieldsId['visible']]) {
                    $scope.subscribeField();
                    $scope.disabled.btn = 1;
                }
            } else {
                if (($rootScope.currentDisplayActionsMode == 1 && $scope.item.itemId) ||
                    ($stateParams.itemId && $rootScope.currentDisplayActionsMode != 1))  //if editing page
                {
                    $scope.disabled.input = 1;
                }
                else  //if adding page
                {
                    $scope.subscribeField();
                    $scope.disabled.btn = 1;
                }
            }
        }

        if (!!$scope.field.defaultValue && ($scope.item[$scope.field.id] == '' || $scope.item[$scope.field.id] == null))
            $scope.item[$scope.field.id] = $scope.field.defaultValue;

        var fieldHeight = parseInt($scope.field.height) || 0;
        if (fieldHeight != 0) {
            $scope.fieldStyle = {"height": fieldHeight + "px"};
        }

        $scope.$watch('item[' + $scope.field.id + ']', function (newValue, oldValue) {
            if (!newValue || !$scope.field.maxLength)
                return;

            if ($scope.field.maxLength - newValue.length < 0) {
                $scope.item[$scope.field.id] = newValue.substr(0, $scope.field.maxLength);
            }
        });
    };

    $scope.initColorPicker = function (){

        if(typeof $scope.item[$scope.field.id] == 'undefined' || !$scope.item[$scope.field.id].length) {
            var isDefaultEmpty = !$scope.item[$scope.field.id];
        }

        //color picker with addon
        angular.element(".colorpicker").colorpicker({color: $scope.item[$scope.field.id], format: 'hex'}).on({
            'changeColor.colorpicker': function (event){
                //if value of input is not empty
                if(isDefaultEmpty || $scope.item[$scope.field.id].length){
                    isDefaultEmpty = false;
                    $scope.item[$scope.field.id] = event.color.toHex();
                }
            }
        });
    };

    $scope.subscribeField = function (var2Watch) {
        if (typeof var2Watch == 'undefined') {
            var2Watch = $scope.field.rFormField;
        }

        var fieldId = 0;
        $.each($scope.view.fields, function (i, el) {
            if (el.fieldName == var2Watch)
                fieldId = el.id;
        });

        var showInfo = true;
        $scope.$watch('item[' + fieldId + ']', function (fieldValue) {
            if (typeof fieldValue == 'undefined')
                return;

            data.text2Transliterate = fieldValue;

            if (inputChangedPromise)
                $timeout.cancel(inputChangedPromise);

            inputChangedPromise = $timeout($scope.transliting, 300);

            if(showInfo && $rootScope.showMultiLangField) {
                Notification.info('Stored data will be used for creating related content for the next language.');
            }
            showInfo = false;
        });
    };

    $scope.$on('editingFieldIdChange', function (event, args)
    {
        if ($scope.item == args.item && $scope.field.id == args.fieldId)
        {
            $.each($scope.includes[args.fieldId], function(index){
                $scope.includes[args.fieldId][index] = $scope.field.listHtml;
            });
            $scope.includes[args.fieldId][args.itemIndex] = $scope.field.itemHtml;

            $timeout(function ()
            {
                $("label[for='" + $scope.field.id + "']").hide();
                $scope.itemIndex = args.itemIndex;
                $('#' + $scope.field.id).focus().blur(function () {
                    $timeout(function () {
                        $scope.includes[args.fieldId][args.itemIndex] = $scope.field.listHtml;
                    });
                });
            });
        }
    });

    $scope.transliting = function () {
        $.post('index.php', data, function (result) {
            $timeout(function () {
                $scope.item[$scope.field.id] = result;
            });
        }, 'json');
    };

    $scope.unlockField = function () {
        if ($scope.unlocked) {
            $scope.unlocked = 0;
            $scope.disabled.input = 1;

            return;
        }

        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg': ' You are trying to change the code page that could be indexed by search engines.' +
                        'In this case, the change of the code will result in a user-404-page',
                        'title': 'Attention!'
                    };
                }
            }
        }).result.then(function () {
            $scope.disabled.input = 0;
            $scope.unlocked = 1;
            $scope.subscribeField($scope.field.fieldName);
        });
    };
});