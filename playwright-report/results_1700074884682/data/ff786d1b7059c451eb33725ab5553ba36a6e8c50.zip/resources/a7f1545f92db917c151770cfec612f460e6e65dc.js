AngularBackend.registerCtrl('EventAutoReplaceFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification)
{
    $scope.eventMasks = false;

    $scope.initField = function ()
    {
        var fields = $scope.getFieldsId($scope.view);
        $scope.$watch('item[' + fields.eventId + ']', function (fieldValue) {
            if(!fieldValue)
                return;

            var data = {
                controller: "FieldController",
                method: "getEventMasks",
                eventId: fieldValue
            };

            $.post('index.php', data, function (result) {
                $scope.$apply(function () {
                    $scope.eventMasks = result;
                    $rootScope.$broadcast('addReplaceMasksEvent', $scope.eventMasks);
                });
            }, 'json');
        });
    };

    $scope.setMask = function(value)
    {
        if(typeof $scope.focusedItem.type == "string")
        {
            $('#' + $scope.focusedItem.$id).insertAtCaret(value);
            $('#' + $scope.focusedItem.$id).trigger('change');
        }
        else
        {
            $scope.focusedItem.type.execCommand('mceInsertContent',false, value);
        }

        return false;
    };
});