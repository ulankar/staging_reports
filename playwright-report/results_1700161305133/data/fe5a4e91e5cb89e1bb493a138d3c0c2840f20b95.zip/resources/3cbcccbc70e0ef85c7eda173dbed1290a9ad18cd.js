AngularBackend.registerCtrl('MailTestSendingCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification)
{
 	$scope.email = '';
    $scope.eventMasks = null;
    $scope.eventMask = {};
    $scope.data = {};

    $scope.$on('addReplaceMasksEvent', function(event, data){
        $scope.eventMasks = data[0]['value'];
    });

    $scope.sendToPerson = function()
    {
        console.log($scope.eventMask);
        if($scope.view.name == 'Site configuration')
        {
            $scope.data = {
                controller: "EventManager",
                method: "sendSiteSettingsMailTest",
                email: $scope.email
            };        }
        else{
            $scope.data = {
                controller: "EventManager",
                method: "sendTemplateMailTest",
                email: $scope.email,
                subject: $scope.item[$scope.getFieldsId($scope.view)['subject']],
                body: $scope.item[$scope.getFieldsId($scope.view)['body']],
                userEventMasks: $scope.eventMask
            };
        }
        $scope.send();
    };

    $scope.send = function ()
    {
        if($scope.email == '')
        {
			Notification.error({title: 'Mail sending', message: 'E-mail address is empty!'});
			return;
        }
        $.post('index.php', $scope.data, function (result)
        {
            var html = '';
            html += (result.technology) ? '</br>' + result.technology + '</br>' : '';
            if(result.smtpParams)
            {
                html += '</br>SMTP properties : </br>';
                for (var prop in result.smtpParams) {
                    html += prop + ' - ' + result.smtpParams[prop] + '</br>';
                }
            }
            if(result.success)
            {
                Notification.success({title: 'Mail sending', message: result.message + html});
            }
            else
            {
				Notification.error({title: 'Mail sending', message: result.message + html, delay: null});
            }
        }, 'json');
    };
});