AngularBackend.registerCtrl('MultiLanguageFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {
    $scope.IDFieldId = 0;
    $scope.titleFieldId = 0;
    $scope.langIdFieldId = 0;

    $scope.showAddButton = true;

    $.each($scope.view.fields, function (fieldId, field) {
        $.each($scope.view.primaryKeys, function (keyId, keyValue) {
            if (keyId == fieldId)
                $scope.IDFieldId = fieldId;
        });
        if (field.fieldName == 'title')
            $scope.titleFieldId = fieldId;

        if (field.fieldName == 'langId') {
            $scope.langIdFieldId = fieldId;
        }
    });

    if ($scope.item[$scope.langIdFieldId] === undefined || $scope.item[$scope.langIdFieldId].value == null) {
        $.each($scope.field.dataSource, function (index, item) {
            if (item.active) {
                $scope.item[$scope.langIdFieldId] = {"value": index};
                return false;
            }
        });
    }
    
    if($scope.field.isMultiLanguage){
        if ($rootScope.showMultiLangField == false && $rootScope.currentDisplayActionsMode == $rootScope.DisplayActionsModes.PopUp && $scope.activeLangs) {
            $.each($scope.field.dataSource, function (index, item) {
                item.isCurrent = false;
                if (index == $scope.item[$scope.langIdFieldId].value)
                    item.active = 0;
            });

            $scope.item[$scope.langIdFieldId].value = null;

            $.each($scope.item[$scope.langIdFieldId].items, function (index, item) {
                $scope.view.fields[$scope.langIdFieldId].dataSource[item.langId].active = 0;
            });
        }
        
        $scope.$watch('item[field.id].value', function () {
            $timeout(function () {
                if($scope.item.itemId == null)
                    $('.selectpicker').selectpicker('selectAll');
                else
                    $('.selectpicker').selectpicker('deselectAll');
                if(!$rootScope.showMultiLangField)
                    $('.selectpicker').selectpicker('deselectAll');

                $('.selectpicker').selectpicker('refresh');
            });
        });

        $scope.multiLangsData = [];
        $scope.$watch('multiLangsData', function () {
            if ($scope.multiLangsData) {
                var data = [];
                $.each($scope.multiLangsData, function (index, item) {
                    data.push(item.id);
                });
                $scope.item['multiLangData'] = data;
            }
        });

        $scope.relatedLanguagesFilter = function (items) {
            var myItems = {};
            $.each(items, function (index, item) {
                if (index != $scope.item[$scope.langIdFieldId].value) {
                    myItems[index] = item;
                }
            });

            return myItems;
        };

        $scope.openRelatedItems = function () {
            if ($scope.item[$scope.langIdFieldId]['items'].length == Object.keys($scope.field['dataSource']).length - 1) {
                $scope.showAddButton = false;
            }

            $uibModal.open({
                    templateUrl: 'RelatedItemList',
                    controller: function ($scope, $rootScope, $modalInstance, $stateParams, $timeout) {
                        $scope.addRelatedItems = function (item) {
                            $rootScope.showMultiLangField = false;
                            var newItem = angular.copy(item);

                            $uibModal.open({
                                templateUrl: '/backend/webcontent/templates/pages/item.html',
                                controller: 'ItemCtrl',
                                size: 'lg',
                                resolve: {
                                    $stateParams: {
                                        viewId: $scope.view.id,
                                        item: newItem,
                                        isCopyItem: true,
                                        isRelatedPopUp: true,
                                        DisplayMode: $rootScope.DisplayActionsModes.PopUp
                                    }
                                }
                            }).result.then(function () {
                                $rootScope.loading = true;

                                var data = {
                                    controller: "MultiLanguageField",
                                    method: "getRelatedItems",
                                    itemId: $stateParams.itemId,
                                    viewId: $scope.view.id
                                };

                                $.post('index.php', data, function (result) {
                                    $scope.$apply(function () {
                                        if (result.success) {
                                            $scope.item[$scope.field.id].items = [];
                                            $.each(result.items, function (index, item) {
                                                $scope.item[$scope.field.id].items.push(item);
                                            });
                                        }
                                        $rootScope.loading = false;
                                    });
                                }, 'json');
                            }, function () {
                                $rootScope.loading = false;
                            });
                        };

                        $scope.searchRelatedItems = function (curItem) {
                            var curLangId = curItem[$scope.langIdFieldId].value;

                            $uibModal.open({
                                templateUrl: '/backend/webcontent/templates/pages/list.html',
                                controller: 'ListCtrl',
                                size: 'lg',
                                scope: $scope,
                                resolve: {
                                    $stateParams: {
                                        viewId: $scope.view.id,
                                        displayMode: 1
                                    }
                                }
                            }).result.then(function (itemData) {
                                if ($.grep($scope.item[$scope.field.id].items, function (n) {
                                        return n.id != itemData.item[$scope.IDFieldId];
                                    }).length == $scope.item[$scope.field.id].items.length) {

                                    var searchedItem = {
                                        id: itemData.item[$scope.IDFieldId],
                                        title: itemData.item[$scope.titleFieldId],
                                        langId: itemData.item[$scope.langIdFieldId].value
                                    };

                                    $rootScope.loading = true;
                                    var data = {
                                        controller: "MultiLanguageField",
                                        method: "getRelatedItems",
                                        itemId: $stateParams.itemId,
                                        viewId: $scope.view.id
                                    };

                                    $.post('index.php', data, function (result) {
                                        $scope.$apply(function () {
                                            if (result.success) {
                                                var error = false;
                                                if (curLangId == searchedItem.langId) {
                                                    error = true;
                                                }
                                                else {
                                                    $.each(result.items, function (index, item) {
                                                        if (searchedItem.langId == item.langId) {
                                                            error = true;
                                                            return false;
                                                        }
                                                    });
                                                }

                                                if (error) {
                                                    Notification.info('Item with this languages is already in relation!');
                                                }
                                                else {
                                                    $scope.item[$scope.field.id].items.push(searchedItem);
                                                }
                                            }
                                            $rootScope.loading = false;
                                        });

                                    }, 'json');
                                }

                                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General
                            }, function () {
                                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                                $rootScope.loading = false;
                            });
                        };

                        $scope.closeRelatedItemPopUp = function () {
                            $scope.$close();
                        };

                        $scope.editRelatedItem = function (itemId) {
                            $scope.activeLangs = false;
                            $uibModal.open({
                                templateUrl: '/backend/webcontent/templates/pages/item.html',
                                controller: 'ItemCtrl',
                                size: 'lg',
                                resolve: {
                                    $stateParams: {
                                        viewId: $scope.view.id,
                                        itemId: itemId,
                                        DisplayMode: $rootScope.DisplayActionsModes.PopUp
                                    }
                                }
                            }).result.then(function (itemData) {
                                if (itemData) {
                                    $.each($scope.item[$scope.field.id].items, function (index, item) {
                                        if (item.id == itemData.item[$scope.IDFieldId]) {
                                            $scope.item[$scope.field.id].items[index].title = itemData.item[$scope.titleFieldId];
                                            $scope.item[$scope.field.id].items[index].langId = itemData.item[$scope.langIdFieldId].value;
                                        }
                                    });
                                }
                                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                            }, function () {
                                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                            });
                        };

                        $scope.deleteRelatedItem = function (itemId) {
                            $uibModal.open({
                                templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
                                controller: 'ModalWindowCtrl',
                                size: 'sm',
                                resolve: {
                                    params: function () {
                                        return {
                                            'msg': 'Delete attribute values ?',
                                            'title': 'Please, confirm action'
                                        };
                                    }
                                }
                            }).result.then(function () {
                                $.each($scope.item[$scope.field.id].items, function (index, item) {
                                    if (item.id == itemId) {
                                        if ($scope.item[$scope.field.id].deleted == undefined)
                                            $scope.item[$scope.field.id].deleted = [];

                                        $scope.item[$scope.field.id].deleted.push($scope.item[$scope.field.id].items[index]);
                                        $scope.item[$scope.field.id].items.splice(index, 1);
                                    }
                                });
                                Notification.info('Item was deleted!');

                            });
                        };
                    },
                    scope: $scope
                })
                .result.then(function (itemData) {
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General
            }, function () {
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            });
        };
    }
});