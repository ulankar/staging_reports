AngularBackend.registerCtrl('PasswordFieldController', function ($scope, $stateParams, $uibModal) {
    $scope.field.validateField = function(__callback){
        if($scope.field.required == "1" && (typeof $scope.item[$scope.field.id] === 'undefined' || $scope.item[$scope.field.id] == '' ))
        {
            __callback(true);
            return;
        }

        if($scope.item[$scope.field.id] != '********') {
            $uibModal.open({
                templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
                controller: 'ModalWindowCtrl',
                size: 'sm',
                resolve: {
                    params: function () {
                        return {
                            'msg': 'Are you sure save new password and send email to administrator?',
                            'title': 'Please, confirm action'
                        };
                    }
                }
            }).result.then(function () {
                    __callback(false);
                }, function () {
                    __callback(true);
                });
        }
        else
        {
            __callback(false);
        }

    };
});