AngularBackend.registerCtrl('DateFieldCntrl', function ($scope, $http, $state, $location, $stateParams, $compile, $rootScope, Notification, $timeout, $uibModal) {

    if($scope.item[$scope.field.id] == undefined || $scope.item[$scope.field.id] == '')
        $scope.item[$scope.field.id] = $scope.field.defaultValue;

    $scope.dateOptions = {
        "singleDatePicker": true,
        "timePicker": false,
        "format": 'DD.MM.YYYY',
        "startDate": $scope.item[$scope.field.id],
        "applyClass": "btn-primary",
        "opens": "right",
        "elementsPosition": "left",
        "timePicker24Hour": false
    }, function (start, end, label) {
        //console.log("New date range selected: ' + start.format('DD.MM.YYYY') + ' to ' + end.format('DD.MM.YYYY') + ' (predefined range: ' + label + ')");
    };

    $scope.initField = function () {

        switch ($scope.field.displayType) {
            case '1' :
                /* Used default options */
                break;
            case '2' :
                $scope.dateOptions.timePicker = true;
                $scope.dateOptions.timePicker24Hour = true;
                $scope.dateOptions.timePickerIncrement = 1;
                $scope.dateOptions.startDate = $scope.item[$scope.field.id];
                $scope.dateOptions.format = 'DD.MM.YYYY H:mm';
                break;
            case '3' :
                /*  Not used, params sets in search.html by data tag
                 $scope.dateOptions.singleDatePicker = false; */
                break;
            case '4':
                $scope.dateOptions.format = 'DD.MM';
                break;
        }
    };

    $scope.showCalendar = function () {
        $('#'+$scope.field.id).focus();
    };

});