AngularBackend.registerCtrl('ModuleLinkBuilderFieldCtrl', function ($scope, $http, $stateParams, $uibModal, $timeout, $rootScope, Notification) {
    //region [Initialize variables, field, select2]

    //region [Variables]
    $scope.addRelation = false;
    $scope.checkedType = '';

    $scope.rules = [];
    $scope.tmpRule = [];
    $scope.availableElements = [];

    $scope.availableTypes = [];
    $scope.elements = {};

    $scope.checkedAttrValues = [];
    $scope.parentOfCurrentEl = [];
    $scope.productsCount = 0;
    //endregion

    //region [Field]
    $scope.initModuleField = function ()
    {
        $scope.availableTypes =  $scope.field.dataSource;
        $scope.tmpRule = ($scope.item[$scope.field.id]) ? $scope.item[$scope.field.id] : [];

        for(var i = 0 ; i < $scope.tmpRule.length ; i++)
        {
            $scope.checkedType = $scope.tmpRule[i]['type']['id'];
            if($scope.tmpRule[i].checkedAttrValues)
            {
                $scope.buildAttrVal(Object.keys($scope.tmpRule[i].elements['attributes'])[0], i);
            }
            else{
                $scope.addItem(true);
            }
        }

        $scope.checkItemsCount($scope.item);
    };

    $scope.addTypeAndItem = function (identificator) {

        $scope.checkedType = identificator;
        if( $scope.getTitleById($scope.checkedType) == 'Attributes')
        {
            $scope.buildAttributes();
        }
        else
            $scope.addItem();
    };

    $scope.getTitleById = function (id) {
        for(var i=0;i<$scope.availableTypes.length;i++)
        {
            if($scope.availableTypes[i].id == id)
                return $scope.availableTypes[i].title;
        }
        return false;
    };

    $scope.getClassById = function (id) {
        for(var i=0;i<$scope.availableTypes.length;i++)
        {
            if($scope.availableTypes[i].id == id)
                return $scope.availableTypes[i].class;
        }
        return false;
    };

    $scope.buildAttributes = function () {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.checkedType,
                    displayMode: 1
                }
            }}).result.then(function(data) {
                if (data)
                {


                    var attrFields = $scope.getFieldsId(data.view);
                    var attrRes = {'id': data.item[attrFields['id']], 'title': data.item[attrFields['title']]};

                    $scope.rules.push({showDelete: false,
                                       type:
                                                {
                                                    id: $scope.checkedType,
                                                    title: attrRes.title,
                                                    class: $scope.getClassById($scope.checkedType)
                                                },
                                       elements: [attrRes]});

                    $scope.tmpRule.push({elements: attrRes.id,
                                         type:
                                         {
                                             id: $scope.checkedType,
                                             title: attrRes.title,
                                             class: $scope.getClassById($scope.checkedType)
                                         }});

                    $scope.fieldValueUpdate();
                    $scope.buildAttrVal(data.item[attrFields['id']]);
                }
            });
    };

    $scope.buildAttrVal = function (attrId, editFlag) {

        data = {
            controller: "ModuleLinkBuilderField",
            method: "getAttributeValuesById",
            attrId: attrId
        };
        $.post('index.php', data, function (result) {
            $timeout(function ()
            {
                if(editFlag != null)
                {
                    var attrRes = {'id': $scope.tmpRule[editFlag].elements, 'title': $scope.tmpRule[editFlag].type['title']};
                    $scope.rules.push({showDelete: false,
                        type:
                        {
                            id: $scope.checkedType,
                            title: $scope.getTypeById($scope.checkedType)
                        },
                        elements: [attrRes]});
                }
                if (result.success)
                {
                    $scope.rules[$scope.rules.length - 1].elements[$scope.rules[$scope.rules.length - 1].elements.length - 1].attrValues = result.attrValues;
                    $timeout(function () {
                        $scope.buildCustomSelect();
                    });
                }
            });
        }, 'json');
    };

    $scope.attributeChanged = function (identificator) {
        $scope.tmpRule[identificator].checkedAttrValues = [];
        $timeout(function () {
            $scope.buildCustomSelect();
        });
    };

    $scope.fieldValueUpdate = function ()
    {
        $scope.item[$scope.field.id] = $scope.tmpRule;
        $scope.checkItemsCount($scope.item);
    };

    $scope.checkItemsCount = function (checkingItem) {
        var tmpData = {
            controller: 'ModuleLinkBuilderField',
            method: 'checkItemsCount',
            item: checkingItem,
            view: $scope.view
        };
        $.post('index.php', tmpData, function (result) {
            if (result.success) {
                $timeout(function () {
                    $scope.productsCount = result.productsCount ? result.productsCount : 0;
                });
            }
            else
                $scope.productsCount = 0;
        }, 'json');
    };
    //endregion

    //region [Select2]
    $scope.buildCustomSelect = function () {
        $(".main-dropdown").select2({
            dropdownParent: $(".modal"),
            minimumResultsForSearch: Infinity
        });
        $(".module-element").select2({
            dropdownParent: $(".modal"),
            minimumResultsForSearch: Infinity
        });
        $('.select2-container--default .select2-selection--single .select2-selection__arrow').css('top', '2px');
        $('.select2-container--default .select2-selection--single, .select2-selection .select2-selection--single').css('padding','8px 12px').css('height', '30px');
        $('.select2-search__field').css('border', 'none');
    };

    $scope.destroyCustomSelect = function () {
        $(".module-element").select2('destroy');
    };

    $scope.reInitCustomSelect = function () {
        $timeout(function () {
            $scope.destroyCustomSelect();
            $scope.buildCustomSelect();
        });
    };

    //endregion

    //endregion

    //region [Actions]

    $scope.deleteRule = function (ruleIndex) {
        $scope.rules.splice(ruleIndex, 1);
        $scope.tmpRule.splice(ruleIndex, 1);
        $scope.fieldValueUpdate();

        $timeout(function () {
            $scope.buildCustomSelect();
        });
    };

    //endregion

    //region [Additional func-s]

    //endregion

    $scope.checkIfAvailable = function () {

        for(var i = 0 ; i < $scope.availableElements.length ; i++)
        {
            if($scope.availableElements[i]['type']['id'] == $scope.checkedType)
                return i;
        }
        return false;
    };


//    region [work with el-s]
    $scope.addItem = function (onEdit)
    {
        var checkAvailResult = $scope.checkIfAvailable();
        if(checkAvailResult === false) {
            $rootScope.loading = true;
            var tmpData = {
                controller: 'ModuleLinkBuilderField',
                method: 'getItemsForRelation',
                viewId: $scope.checkedType,
                classToUse: $scope.getClassById($scope.checkedType)
            };
            $.post('index.php', tmpData, function (result) {
                if (result.success) {
                    $timeout(function () {
                        if (result.items.length > 0) {

                            var checkedType = $scope.getCheckedType();

                            $scope.rules.push({
                                'type': checkedType, 'elements': result.items
                            });
                            $scope.availableElements.push({
                                'type': checkedType, 'elements': result.items
                            });

                            if(!onEdit)
                                $scope.tmpRule.push({'type': checkedType});

                            $timeout(
                                function () {
                                    $scope.buildCustomSelect();
                                }
                            );
                        } else {
                            Notification.info('There is no items');
                        }
                        $rootScope.loading = false;
                    });
                }
            }, 'json');
        }
        else{
            $scope.rules.push($scope.availableElements[checkAvailResult]);
            if(!onEdit)
                $scope.tmpRule.push({'type': $scope.getCheckedType()});
            $timeout(
                function () {
                    $scope.buildCustomSelect();
                }
            );
        }
    };

    $scope.getCheckedType = function () {
        return {
            id: $scope.checkedType,
            title: $scope.availableTypes[$scope.getTypeById($scope.checkedType)]['title'],
            code: $scope.getTypeById($scope.checkedType),
            class: $scope.getClassById($scope.checkedType)
        };
    };

    $scope.getTypeById = function (currentType) {
        for(var key in $scope.availableTypes)
        {
            if(currentType == $scope.availableTypes[key]['id'])
            {
                return key;
            }
        }
        return false;
    };

    $scope.attributeToComfort = function (ruleId) {

        var tmp = {};
        if(!$scope.tmpRule[ruleId].type['attrId'])
        {
            $scope.tmpRule[ruleId].type['attrId'] = $scope.tmpRule[ruleId].elements;
        }
        tmp[$scope.tmpRule[ruleId].type['attrId']] = {};
        for(var i = 0 ; i < $scope.tmpRule[ruleId].checkedAttrValues.length ; i++)
        {
            tmp[$scope.tmpRule[ruleId].type['attrId']][$scope.tmpRule[ruleId].checkedAttrValues[i]] = {'id': $scope.tmpRule[ruleId].checkedAttrValues[i]};
        }
        $scope.tmpRule[ruleId].elements = {'attributes': tmp};
    };
//    endregion

});