AngularBackend.registerCtrl('FileFieldCtrl', function ($scope, $compile, $timeout, $uibModal, $stateParams)
{
    $scope.itemIndex = 0;
    $scope.typeOfField = 'files';
    $scope.openKCFinder = function (fieldId, typeOfField)
    {
        $scope.typeOfField = typeOfField;
        if($scope.item[fieldId] && $scope.item[fieldId].origin)
            $scope.imageDir =  $scope.item[fieldId].origin.substring( 0, $scope.item[fieldId].origin.lastIndexOf( "/" ) + 1).replace('/frontend/webcontent/', '').replace(document.location.origin, '');
        else if($stateParams.itemId && $scope.field.defaultValue)
            $scope.imageDir = typeOfField + '/' + $scope.field.defaultValue + '/' + $stateParams.itemId;
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/filemanager.html',
            size: 'lg',
            scope: $scope,
            resolve: {
            }
        }).result.then(function(data) {
                    $scope.item[fieldId] = {};
                    $scope.item[fieldId].origin = document.location.origin + data.url;
                    $scope.item[fieldId].preview = document.location.origin + data.url;
            });
    };

    $scope.$on('editingFieldIdChange', function(event, args)
    {
        if($scope.item.origin == args.item.origin && $scope.field.id == args.fieldId)
        {
            $scope.openKCFinder(args.fieldId, 'images');
        }
    });
    if($scope.item[$scope.field.id] && $scope.item[$scope.field.id].origin)
        $scope.fileExtension = '.' + $scope.item[$scope.field.id].origin.split('.').pop();
});