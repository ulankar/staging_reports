AngularBackend.registerCtrl('ProductVariantsFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {

    $scope.productIDFieldId = 0;
    $scope.productDisplayField = '';
    $scope.isMainField = 0;
    $scope.visibleFieldId = 0;

	/**
	 * if it copying, id of item which was copied from need to save
     * if make for change cut itemId to copied from on backend
     */
    if($scope.copyMode) {
        $scope.item[$scope.field.id].copiedFromItemId = $scope.stateItemId;
        $scope.item[$scope.field.id] = undefined;
    }

    if($scope.item[$scope.field.id] == undefined || $scope.copyMode)
    {
        $scope.item[$scope.field.id] = $scope.item[$scope.field.id] || {};
        $scope.item[$scope.field.id].items = $scope.item[$scope.field.id].items || [];
        $scope.item[$scope.field.id].items.push({id: ':relationId', isMain: 0, title: ""});
        $scope.item[$scope.field.id].mask = $scope.item[$scope.field.id].mask || [];
    }

    $.each($scope.view.fields, function (fieldId, field) {
        $.each($scope.view.primaryKeys, function (keyId, keyValue) {
            if (keyId == fieldId)
                $scope.productIDFieldId = fieldId;
        });

        if (field.fieldName == 'title')
            $scope.productDisplayField = fieldId;

        if (field.fieldName == 'isMain')
            $scope.isMainField = fieldId;

        if (field.fieldName == 'visible')
            $scope.visibleFieldId = fieldId;
    });

    /*$scope.$watch('item[' + $scope.productDisplayField + ']',function() {
        if ($scope.item[$scope.productIDFieldId] == undefined){
            $scope.item[$scope.field.id].items[0].title = $scope.item[$scope.productDisplayField];
        }
        else {
            $.each($scope.item[$scope.field.id].items, function (index, product) {
                if (product.id == $scope.item[$scope.productIDFieldId]) {
                    $scope.item[$scope.field.id].items[index].title = $scope.item[$scope.productDisplayField];
                }
            });
        }
    });*/

    $scope.addProduct = function() {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.rSearchViewId,
                    displayMode: 2
                }
            }
        }).result.then(function (itemData) {
                if (itemData == undefined)
                    return;

                if ($scope.item[$scope.field.id].items == undefined)
                    $scope.item[$scope.field.id].items = [];

                $.each(itemData.selected, function (index, element) {
                    if ($.grep($scope.item[$scope.field.id].items, function (n) {
                            return n.id != element[$scope.productIDFieldId];
                        }).length == $scope.item[$scope.field.id].items.length) {

                        var item = {};
                        item.id =  element[$scope.productIDFieldId];
                        item.title =  element[$scope.productDisplayField];
                        item.isMain =  element[$scope.isMainField];
                        item.visible =  element[$scope.visibleFieldId];

                        $scope.item[$scope.field.id].items.push(item);
                    }
                });

                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            }, function () {
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
            });
    };

    $scope.updateIsMain = function(product) {
        angular.forEach($scope.item[$scope.field.id].items, function(item, index) {
            item.isMain = '0';
        });

        product.isMain = '1';
    };

    $scope.deleteProduct = function(position) {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete product from variants?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {

                $scope.item[$scope.field.id].items.splice(position, 1);
                Notification.info('Product was deleted');

            });
    };
    
    $scope.onDragEnd = function () {
        $.each($scope.item[$scope.field.id].mask, function(i) {
            $scope.item[$scope.field.id].mask[i].order = i + 1;
        });
    };  

    $scope.addMaskItem = function()
    {
        $uibModal.open({
            templateUrl: 'MaskPopUp',
            controller: function($scope, $modalInstance){
                $scope.selectMask = function(mask)
                {
                    $modalInstance.close(mask);
                };
            },
            scope: $scope
        }).result.then(function(mask)
            {
                if(!$scope.item[$scope.field.id].mask)
                    $scope.item[$scope.field.id].mask = [];

                if ($.grep($scope.item[$scope.field.id].mask, function (n){return n.id != mask.id;}).length == $scope.item[$scope.field.id].mask.length) {
                    $scope.item[$scope.field.id].mask.push(mask);
                    Notification.info('Mask "' + mask.value + '" was added!');
                }
                else
                {
                    Notification.info('Mask "' + mask.value + '" already exist!');
                }

            });
    };

    $scope.deleteMaskItem = function(mask)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete mask "' + mask.value + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {
                var index = $scope.item[$scope.field.id].mask.indexOf(mask);
                $scope.item[$scope.field.id].mask.splice(index, 1);
                Notification.info('mask "' + mask.value + '" was deleted!');
            });
    };

    $scope.checkSelfVariant = function (product) {
        //return !(product.id == ':relationId' || (product.id == $scope.stateItemId && !$scope.copyMode));
        return $scope.item[$scope.field.id].items.length > 1;
    };
});