/**
 * Created by opium on 05.08.2016.
 */

/**
 * Also works with inner views, which
 */

var FieldsValidation = {

	/**
	 * Using for validation while publishing entities (actually products)
	 * @param __callback
	 */
	functionalNameValidation: function (__callback) {
		var $scope = this;

		$scope.$root.loading = true;

		var attributes = $.extend(true, {}, Array.isArray($scope.$root.attributes) ? {} : $scope.$root.attributes);
		$.each(attributes, function (key, item) {
			delete item['dataSource'];
		});

		var data = {
			controller: "PublishingValidationController",
			method: "productValidation",
			attributes: attributes,
			fieldsId: $scope.fieldsId,
			viewId: $scope.view.id,
			item: $scope.item,
			itemId: $scope.stateItemId
		};

		$.ajax({
			url: 'index.php',
			dataType: "json",
			type: "post",
			data: data,
			complete: function (data) {
				var restone = data.responseJSON;
				
				if(restone.success){
					__callback(false);
				} else {
					$scope.errorNotification(restone.message);
					__callback(true);
				}
			}
		});
	},

	/**
	 * Using for validation length of field
	 * Example: fieldLength,116
	 * @param __callback
	 * @param maxLength
	 */
	fieldLength: function (__callback, maxLength) {
		var $scope = this;

		var validateResult = $scope.item[$scope.fieldsId['body']].length > maxLength;

		if(validateResult) {
			$scope.getWebText('not_valid_field_length', 'field length must be no longer than '+ maxLength +' symbols. Now - ', function (text) {
				$scope.errorNotification('"'+$scope.view.fields[$scope.fieldsId['body']].displayName +'" '+ text + $scope.item[$scope.fieldsId['body']].length);
			});
		}

		__callback(validateResult);
	},

	/*checkboxSetOtherToZero: function () {

	},

	/!**
	 * For fields, where checkbox is in inner view, for example, for 33 field
	 * @param __callback
	 * @param fieldName
	 * @param difficultFieldKey
	 *!/
	checkboxSetOtherToZeroForDifficultField: function (__callback, fieldName, difficultFieldKey) {
		var $scope = this;

		var field = $scope.view.fields[$scope.fieldsId[difficultFieldKey]];
		var innerView = field.dataSource;

		var fieldIds = $scope.getFieldsId(innerView);

		var checkBoxValue = fieldIds[fieldName];
		
		var data = {
			controller: "PublishingValidationController",
			method: "checkboxSetOtherToZero"
		};

		__callback(true);
	}*/
};