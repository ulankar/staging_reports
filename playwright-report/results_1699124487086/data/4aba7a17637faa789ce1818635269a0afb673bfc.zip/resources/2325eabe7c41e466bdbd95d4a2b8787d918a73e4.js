AngularBackend.registerCtrl('CheckBoxFieldCtrl', function ($scope)
{
    $scope.initInEditableMode = function(){
        console.log('initInEditableMode ');
    };

    $scope.disableAtList = true;
    $scope.$on('initInEditableMode', function (event, args)
    {
        if($scope.field.id == args.field.id) {
            $scope.disableAtList = false;
        }
    });
});