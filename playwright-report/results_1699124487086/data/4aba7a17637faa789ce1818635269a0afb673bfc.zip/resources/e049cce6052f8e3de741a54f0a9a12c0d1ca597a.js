AngularBackend.registerCtrl('EtapListsController', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification)

{
    $scope.sitesList = {};
    $scope.getEtapLists = function () {
        $scope.viewFields = $scope.getFieldsId($scope.view);
        var data = {
            controller: "EtapListsField",
            method: "getEtapLists",
            etapId: $scope.item[$scope.viewFields['id']]
        };

        $.post('index.php', data, function (result) {
            var html = "";
            var key = 1;
            for(var i = 0 ; i < result.length; i++){
                html +='<tr>' +
                    '<td>'+key+'</td><td>'+result[i].teamAName+'</td>' +
                    '<td>'+result[i].teamBName+'</td><td>'+result[i].tour+'</td>' +
                    '<td>'+result[i].teamAScore+'</td><td>'+result[i].teamBScore+'</td>' +
                    '<td>'+result[i].date+'</td>' +
                    '</tr>';
                key++;
            }
            $('#etapLists').html(html);
        }, 'json');
    };

});