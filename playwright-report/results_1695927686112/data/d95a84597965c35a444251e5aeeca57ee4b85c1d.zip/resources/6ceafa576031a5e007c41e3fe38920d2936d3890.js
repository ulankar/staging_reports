AngularBackend.registerCtrl('DropDownFieldCtrl', function ($scope, $uibModal, $rootScope, $timeout, Notification) {
    $scope.showLoader = false;
    $scope.withoutBlank = {};

    $scope.showFieldMode = {
        Item: 1,
        Search: 2,
        List: 3
    };

    var rFormFieldValue = null;
    var fieldsId = $scope.getFieldsId($scope.view);
    var rFormFiledId = fieldsId[$scope.field.rFormField];

    $scope.currentShowFieldMode = null;

    $scope.initField = function (showMode) {

        if($scope.item[$scope.field.id] == undefined) {
            return;
        }
        
        var displayName = $scope.field.rDisplayFields.split(' as ');
        if(displayName.length>0)
            $scope.field.rDisplayFields = displayName[displayName.length-1];

        if($scope.field.defaultValue) {
            $scope.item[$scope.field.id] = $scope.field.defaultValue;
        }

        if($scope.field.required == 1 && ($scope.item[$scope.field.id] == undefined || $scope.item[$scope.field.id] == '')) {
            var firstElement = $scope.field.dataSource[Object.keys($scope.field.dataSource)[0]];
            $scope.item[$scope.field.id] = firstElement[$scope.field.rFieldName];
        }

        $scope.currentShowFieldMode = showMode;
        if ($scope.field.rFormField == "" || typeof $scope.field.rFormField == "undefined" || $scope.field.rFormField == null || $scope.currentShowFieldMode != $scope.showFieldMode.Item) {
            return;
        }

        var watchField = "";
        if($scope.view.fields[rFormFiledId].fieldTypeId == 13) {
            watchField = 'item[' + rFormFiledId + '].value';
        } else {
            watchField = 'item[' + rFormFiledId + ']';
        }

        $scope.$watch(watchField, function (fieldValue) {
            if (typeof fieldValue == 'undefined') {
                return;
            }

            if($scope.field.displayType == 4) {
                //filtering by rFormField value
                rFormFieldValue = typeof $scope.item[rFormFiledId] == "object" ? $scope.item[rFormFiledId]['value'] : $scope.item[rFormFiledId];

                var currentTemplates = $scope.rFormFieldFilter($scope.field.dataSource);
                if ($scope.item[fieldsId[$scope.field.fieldName]] === undefined || currentTemplates[$scope.item[fieldsId[$scope.field.fieldName]]] === undefined) {
                    $.each($scope.field.dataSource, function (index, item) {
                        if(item.langId == rFormFieldValue){
                            $scope.item[fieldsId[$scope.field.fieldName]] = item.id;
                            return false;
                        }
                    });
                }
            } else {
                $scope.field.visible = fieldValue == $scope.field.availableValues;

                if (!$scope.field.visible) {
                    $scope.item[$scope.field.id] = null;
                }
            }
        });
    };

    $scope.rFormFieldFilter = function (items) {
        if (!+rFormFieldValue) {
            return items;
        }
        var result = {};
        angular.forEach(items, function (value, key) {
            if (items[key][$scope.field.rFormField] == rFormFieldValue) {
                result[key] = value;
            }
        });

        return result;
    };
    
    $scope.$on('editingFieldIdChange', function (event, args)
    {
        /*if ($scope.item == args.item && $scope.field.id == args.fieldId)
        {
            $.each($scope.includes[args.fieldId], function (index) {
                $scope.includes[args.fieldId][index] = $scope.field.listHtml;
            });

            $scope.includes[args.fieldId][args.itemIndex] = $scope.field.itemHtml;

            $timeout(function () {
                $("label[for='" + $scope.field.id + "']").hide();
                $scope.itemIndex = args.itemIndex;
                var e = $.Event("keypress");
                e.which = 13;
                $('#' + $scope.field.id).focus().blur(function () {

                    $timeout(function () {
                        $scope.includes[args.fieldId][args.itemIndex] = $scope.field.listHtml;
                    });

                }).parent().removeClass('col-sm-3');
            });
        }*/
    });

    if ($scope.field.displayType == '3')
    {
        $scope.autoCompleteItem = $scope.field.dataSource[$scope.item[$scope.field.id]];

        $scope.$watch('autoCompleteItem.' + $scope.field.rDisplayFields, function () {
            if ($scope.autoCompleteItem == undefined || $scope.autoCompleteItem.title == '')
                $scope.item[$scope.field.id] = '';
        });
    }

    $scope.labelDeviceAutoComplete = {
        source: function (request, response) {
            var array = [];
            var data = {
                controller: "FieldController",
                method: "getDropDownAutoComplete",
                countOnPage: 20,
                currentPage: 0,
                orderField: '',
                orderMethod: '',
                viewId: $scope.field.viewId,
                fieldId: $scope.field.id,
                term: request.term
            };
            $timeout(function () {
                $scope.showLoader = true;
            });

            $.post('index.php', data, function (result) {
                if (result.success) {
                    $timeout(function () {
                        $.each(result.items, function (a, b) {
                            array.push(b);
                        });

                        $scope.showLoader = false;
                        response(array);
                    });
                }
            }, 'json');
        },
        minLength: 2,
        select: function (event, ui) {
            this.value = ui.item[$scope.field.rDisplayFields];

            $timeout(function () {
                switch ($scope.currentShowFieldMode)
                {
                    case $scope.showFieldMode.Item:
                        $scope.item[$scope.field.id] = ui.item.id;

                        break;

                    case $scope.showFieldMode.Search:
                        if ($rootScope.search)
                            $rootScope.search[$scope.field.id] = ui.item.id;
                        break;
                }
            });
            return false;
        },

        _renderItem: function (ul, item) {
            return $("<li>").data("item.autocomplete", item)
                .append("<a>" + item[$scope.field.rDisplayFields] + "</a>")
                .appendTo(ul);
        },

        focus: function (event, ui) {
            $timeout(function () {
                $scope.autoCompleteItem = ui.item;
            });
        }
    };
    
    $scope.field.validateField = function (__callback) {
        __callback($scope.field.required == "1" && (typeof $scope.item[$scope.field.id] === 'undefined' || $scope.item[$scope.field.id] == '' ));
    };
});
