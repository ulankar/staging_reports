AngularBackend.registerCtrl('ManyToOneFieldCtrl', function ($scope, $uibModal, $timeout, Notification, $rootScope)
{
    $scope.includes = [];

    $scope.fileFieldId = 0;
    $scope.orderFieldId = 0;
    $scope.searchFieldId = 0;
    $scope.itemIdFieldId = null;

    $scope.EditModes = {
        General: 1,
        Inline: 2
    };

    $scope.currentEditMode = $scope.EditModes.General;

    var fieldsId = $scope.getFieldsId($scope.field.dataSource);

    if($scope.item[$scope.field.id] == undefined) {
        $scope.item[$scope.field.id] = {};
        $scope.item[$scope.field.id].items = [];
    }
  
    $scope.init = function() {
        /*if($scope.item[$scope.field.id] == undefined) {
            $scope.item[$scope.field.id] = [];
        }*/

        $.each($scope.field.dataSource.fields, function(fieldId, field)
        {
            $scope.includes[fieldId] = [];
            if($scope.item[$scope.field.id].items) {
                $.each($scope.item[$scope.field.id].items, function (itemId, item) {
                    $scope.includes[fieldId][itemId] = field.listHtml;
                });
            }

            if($scope.field.displayType == 2)
            {
                if(field.fieldTypeId == 7)
                    $scope.fileFieldId = fieldId;
            }


        });

        if($scope.field.displayType == 3)
        {
            $.each($scope.field.dataSource.fields, function (fieldId, field) {
                if (field.fieldName == $scope.field.rSourceLinkField)
                    $scope.searchFieldId = field.id;
            });
        }

        $scope.onDragEnd();
    };

    $.each($scope.field.dataSource.fields, function(fieldId, field){
        $.each($scope.field.dataSource.primaryKeys, function(keyId, keyValue){
            if(keyId == fieldId)
                $scope.itemIdFieldId = fieldId;
        });
    });

    $scope.$on('ngRepeatFinished', function() {
        $.each($scope.field.dataSource.fields, function(fieldId, field) {
            $scope.initInEditableMode(field);
        });
    });
    
    $scope.drugNDropItemsRef = $scope.item[$scope.field.id].items;

    console.log($scope.drugNDropItemsRef);

    $scope.onDragEnd = function () {

        if(!$scope.field.rSourcePointerField)
            return;

        $.each($scope.item[$scope.field.id].items, function(i) {
            this[fieldsId[$scope.field.rSourcePointerField]] = i + 1;
        });
    };

   $scope.editInlineField = function(fieldId, item, itemIndex)
   {
       $scope.currentEditMode =  $scope.EditModes.Inline;
       $scope.$broadcast('editingFieldIdChange',{"fieldId": fieldId, 'item': item, 'itemIndex': itemIndex});
   };

   $scope.initEditField = function(fieldId)
   {
       setInterval(function(){
           $('#' + fieldId).focus();
       }, 10);
   };
    
   //$scope.sortableOptions = {
   //   disabled: $scope.field.readonly == '1'
   //};

   $scope.deactivateFieldEditing = function(fieldId, itemId)
   {
       if($scope.editingFieldId && $scope.includes[fieldId][itemId] == $scope.field.dataSource.fields[fieldId].listHtml) {
           $timeout(function () {
               $('#' + $scope.editingFieldId).blur();
               $scope.editingFieldId = 0;
           });
       }
   };

    $scope.addItem = function (value) {
        var item = {};
        $.each($scope.field.dataSource.fields, function (fieldId, field) {
            if ($scope.field.dataSource.primaryKeys[fieldId] == undefined)
                item[fieldId] = '';
        });

        var maxItemsCount = $scope.field.availableValues;
        var itemsCount = Object.keys($scope.item[$scope.field.id].items).length;
        if (maxItemsCount != null && (itemsCount >= maxItemsCount)) {
            Notification.error({
                title: 'Error',
                message: "Reached limit count of items. Maximum: " + maxItemsCount,
                delay: null
            });
            $rootScope.loading = false;
            return;
        }

        if ($scope.field.displayType == '3') {
            $rootScope.loading = true;

            var data = {
                controller: "ManyToOneField",
                method: "getSearchItemsViewId",
                viewId: $scope.field.rSearchViewId,
                rSourceLinkField: $scope.field.rSourceLinkField
            };

            $.post('index.php', data, function (result) {
                if (result.success) {
                    var viewId = result.viewId;
                    $uibModal.open({
                        templateUrl: '/backend/webcontent/templates/pages/list.html',
                        controller: 'ListCtrl',
                        size: 'lg',
                        scope: $scope,
                        resolve: {
                            $stateParams: {
                                viewId: viewId,
                                displayMode: 1
                            }
                        }
                    }).result.then(function (itemData) {
                        /*if ($scope.item[$scope.field.id].clear != undefined && $scope.item[$scope.field.id].clear)
                            $scope.item[$scope.field.id] = [];*/

                        var pFieldId;
                        $.each(itemData.view.primaryKeys, function (pId, p) {
                            pFieldId = p;
                        });

                        item[$scope.searchFieldId] = itemData.item[pFieldId];

                        $scope.item[$scope.field.id].items.push(item);

                        $.each($scope.field.dataSource.fields, function (fieldId, field) {
                            if ($scope.item[$scope.field.id].items)
                                $scope.includes[fieldId][$scope.item[$scope.field.id].items.length - 1] = field.listHtml;
                        });

                        $rootScope.loading = false;
                        $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                    }, function () {
                        $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                        $rootScope.loading = false;
                    });
                }
            }, 'json');
        } else {
            /*if ($scope.item[$scope.field.id].clear != undefined && $scope.item[$scope.field.id].clear)
                $scope.item[$scope.field.id] = [];*/

            if ($scope.field.displayType == 2 && $scope.fileFieldId && value) {
                item[$scope.fileFieldId] = value;
            }

            $scope.item[$scope.field.id].items.push(item);

            $.each($scope.field.dataSource.fields, function (fieldId, field) {
                if ($scope.item[$scope.field.id].items)
                    $scope.includes[fieldId][$scope.item[$scope.field.id].items.length - 1] = field.listHtml;
            });

            $scope.edit(item);
        }
        $rootScope.loading = false;
    };

    $scope.edit = function (item)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/item.html',
            controller: 'ItemCtrl',
            size: 'lg',
            resolve: {
                $stateParams :{
                    view : $scope.field.dataSource,
                    item: item,
                    DisplayMode: 2
                }
            }
        }).result.then(function (itemData)
            {
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                $rootScope.loading = false;
            },function(){
                $rootScope.currentDisplayActionsMode = $rootScope.DisplayActionsModes.General;
                $rootScope.loading = false;
            });
    };

    $scope.remove = function($index, item){
       $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete item ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
       }).result.then(function() {

           if(item[$scope.itemIdFieldId]) {
               $scope.item[$scope.field.id].deleted.push(item);
           }

           $scope.item[$scope.field.id].items.splice($index, 1);

           /*if($scope.item[fieldId].length == 0)
           {
               $scope.item[fieldId] = {clear: 1};
           }*/

           Notification.success('Item was deleted from angular model');
           $rootScope.loading = false;
       });
    };

    $scope.addFiles = function(){
        $scope.imageDir = 'images/';
        $scope.multiSelect = 1;
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/filemanager.html',
            size: 'lg',
            scope: $scope,
            resolve: {
            }
        }).result.then(function(data) {
                if(data && data.files)
                {
                    $.each(data.files, function(index, file){
                        $scope.addItem(document.location.origin + file);
                    });
                }
                $rootScope.loading = false;
            });
    };

    $scope.initInEditableMode = function(field){
        $rootScope.$broadcast('initInEditableMode', {"field": field});
    };
    
    $scope.field.validateField = function(__callback){
        __callback($scope.field.required == "1" && !$scope.item[$scope.field.id].items.length);
    };
});
