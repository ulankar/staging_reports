AngularBackend.registerCtrl('LinkFieldCtrl', function ($scope, $compile, $timeout, $uibModal)
{
    $scope.$on('editingFieldIdChange', function(event, args)
    {
        if($scope.item == args.item && $scope.field.id == args.fieldId)
        {
            $scope.showLabel = false;
            $scope.itemIndex = args.itemIndex;
            $scope.browsePages();
        }
    });

    $scope.browsePages = function()
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: 1,
                    displayMode: 1
                }
            }
        }).result.then(function(itemData){
            var data = {
                controller: "FieldController",
                method: "getPageUrl",
                pageParams: itemData.item,
                viewId: itemData.viewId
            };

            $.post('index.php', data, function (result) {
                $timeout(function () {
                    if (result.success)
                    {
                        $scope.item[$scope.field.id] = result.url;
                    }
                });
            }, 'json');
        });
    };

    $scope.reset = function(fieldId)
    {
        $scope.item[fieldId] = '';
        //$(document.getElementById(fieldId)).val('');
    }
});