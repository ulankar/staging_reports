AngularBackend.registerCtrl('NestedAttributeFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {

    $scope.namedFields = $scope.getFieldsId($scope.view);

    $scope.subscribeFieldId = 0;
    $.each($scope.view.fields, function (i, el) {
        if (el.fieldName == $scope.field.rFormField) {

            $scope.$watch('item[' + el.id + ']', function (fieldValue) {
                $scope.field.visible = fieldValue == $scope.field.availableValues;

                $scope.view.fields[$scope.namedFields.useInFilter].readonly = fieldValue == $scope.field.availableValues;
            });
        }
    });

    if($scope.item[$scope.field.id] && $scope.item[$scope.view.fields[$scope.namedFields.attributeTypeId].id] == 6)
    {
        $scope.view.fields[$scope.namedFields.attributeTypeId].readonly = 1;
    }

    if($scope.item[$scope.field.id]) {
        $.each($scope.item[$scope.field.id], function (i) {
            if ($scope.item[$scope.field.id][i].measure && $scope.item[$scope.field.id][i].measure.id)
                $scope.item[$scope.field.id][i].measure.visible = $scope.item[$scope.field.id][i].measure.visible == 'true';
        });
    }
    
    $scope.onDragEnd = function () {
        $.each($scope.item[$scope.field.id], function(i) {
            $scope.item[$scope.field.id][i].order = i + 1;
        });
    };

    $scope.addItem = function()
    {
        $uibModal.open({
            templateUrl: 'AutoTitlePopUp',
            controller: function($scope, $modalInstance){
                $scope.selectMask = function(mask)
                {
                    $modalInstance.close(mask);
                };
            },
            scope: $scope
        }).result.then(function(mask)
            {
                mask = angular.copy(mask);

                if(!$scope.item[$scope.field.id])
                    $scope.item[$scope.field.id] = [];

                if(mask.measure && mask.measure.id)
                    mask.measure.visible = true;
                
                $scope.item[$scope.field.id].push(mask);

                Notification.info('Mask "' + mask.value + '" was added!');
            });
    };

    $scope.deleteItem = function(mask)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete mask "' + mask.value + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {
                var index = $scope.item[$scope.field.id].indexOf(mask);
                $scope.item[$scope.field.id].splice(index, 1);
                Notification.info('mask "' + mask.value + '" was deleted!');
            });
    };

    $scope.setFocus = function($event){
        if($event.currentTarget)
            $event.currentTarget.focus();
    };
});