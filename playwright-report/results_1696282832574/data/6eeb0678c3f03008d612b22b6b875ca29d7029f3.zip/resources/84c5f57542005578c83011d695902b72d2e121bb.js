AngularBackend.registerCtrl('ManageAttributesFieldCtrl', function ($scope, $stateParams, $uibModal, $timeout, $rootScope, Notification) {
    $scope.elements = {};

    $scope.IDFieldId = 0;
    $scope.displayField = '';
    $scope.searchFieldId = 0;

    $.each($scope.field.dataSource.fields, function (fieldId, field) {
        $.each($scope.field.dataSource.primaryKeys, function (keyId, keyValue) {
            if (keyId == fieldId)
                $scope.IDFieldId = fieldId;
        });
        if (field.fieldName == 'value')
            $scope.displayField = fieldId;

        if (field.fieldName == 'attributeId')
            $scope.searchFieldId = fieldId;
    });

    $scope.initField = function () {
        if ($scope.field.rFormField == "" || typeof $scope.field.rFormField == "undefined") {
            $scope.getElements();
            return;
        }

        if (typeof var2Watch == 'undefined') {
            var2Watch = $scope.field.rFormField;
        }

        var fieldId = 0;
        $.each($scope.view.fields, function (i, el) {
            if (el.fieldName == var2Watch)
                fieldId = el.id;
        });

        $scope.$watch('item[' + fieldId + ']', function (fieldValue) {
            if (typeof fieldValue == 'undefined')
                return;

            $scope.getElements(fieldValue);
        });
    };

    $scope.getElements = function(fieldValue)
    {
        var data = {
            controller: "ManageAttributesField",
            method: "GetElements",
            field: $scope.field,
            rFormFieldValue: fieldValue,
            itemId: $stateParams.itemId
        };

        $.post('index.php', data, function (result) {
            if (result.success) {
                $scope.$apply(function () {
                    $scope.elements = result.items;
                    $rootScope.attributes = $scope.elements;
                });
            }
        }, 'json');
    };

    $scope.field.saveFieldData = function (itemId) {
        if(itemId == undefined) return;
        var params = {};

        $.each($scope.elements, function (elId, element) {
            params[elId] = {};
            params[elId].values = element.values;
            params[elId].fieldTypeId = element.fieldTypeId;
        });

        var val = {
            controller: "ManageAttributesField",
            method: "SaveManageAttributesField",
            viewId: $scope.view.id,
            itemId: itemId,
            fieldId: $scope.field.id,
            data: params
        };

        $.post('index.php', val, function (result) {
            if (result.success) {

            }
        }, 'json');
    };

    $scope.addItem = function () {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.defaultValue,
                    displayMode: 2
                }
            }
        }).result.then(function (itemData) {
            var data = {
                controller: "ManageAttributesField",
                method: "GetElement",
                //item: itemData.item,
                items: itemData.selected,
                viewId: $scope.field.defaultValue,
                dataSourceId: $scope.view.id,
                fieldId: $scope.field.id
            };

            $.post('index.php', data, function (result) {
                if (result.success)
                {
                    $timeout(function () {

                        if (!Object.keys($scope.elements).length) {
                            $scope.elements = {};
                        }

                        var addedAttributesStr = "";
                        var existAttributesStr = "";
                        $.each(result.elements, function(elementId, element){
                            if ($scope.elements[elementId] == undefined)
                            {
                                $scope.elements[elementId] = element;
                                addedAttributesStr += $scope.elements[elementId].title + "<br>";
                            }
                            else
                            {
                                if($scope.elements[elementId].visible)
                                    existAttributesStr += $scope.elements[elementId].title + "<br>";

                                $scope.elements[elementId].visible = true;
                            }
                        });

                        if(addedAttributesStr != "")
                            Notification.success('<b>Attributes:</b> <br>' + addedAttributesStr + ' <b>was added!</b>');

                        if(existAttributesStr != "")
                            Notification.info('<b>Attributes:</b> <br>' + existAttributesStr + ' existing in list of attributes!');

                    });
                }
            }, 'json');
        }, function () {
            $rootScope.currentDisplayActionsMode = $scope.DisplayActionsModes.General;
        });
    };

    // broadcast to autotitle
    $scope.$watchCollection('elements', function(elements){
        $.each($scope.elements, function(elId, el){
            $scope.$watchCollection('elements[' + elId + '].values', function(element){
                $rootScope.$broadcast('attributeChangeEvent', $scope.elements[elId]);

            });
            $scope.$watchCollection('elements[' + elId + '].values[0]', function(element){
                $rootScope.$broadcast('attributeChangeEvent', $scope.elements[elId]);
            });
        });

        $rootScope.attributes = $scope.elements;
    });

    $scope.changeNestedValue = function(){
        $.each($scope.elements, function(elId, el){
            if($scope.elements[elId].fieldTypeId == 10)
            {
                $scope.elements[elId].values[0] = $scope.getNestedAttributeValue($scope.elements[elId]);
            }
        });
    };

    $scope.addAttributeItem = function (elementId) {
        $scope.search = {};
        $scope.search[$scope.searchFieldId] = elementId;

        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/pages/list.html',
            controller: 'ListCtrl',
            size: 'lg',
            scope: $scope,
            resolve: {
                $stateParams: {
                    viewId: $scope.field.dataSource.id,
                    displayMode: 1,
                    search: $scope.search
                }
            }
        }).result.then(function (itemData) {
            $rootScope.currentDisplayActionsMode = $scope.DisplayActionsModes.General;

            if ($scope.elements[elementId].values == undefined)
                $scope.elements[elementId].values = [];

            if ($.grep($scope.elements[elementId].values, function (n)
                {
                    $rootScope.loading = false;
                    return n.id != itemData.item[$scope.IDFieldId];
                }).length == $scope.elements[elementId].values.length) {

                var item = {};
                item.id = itemData.item[$scope.IDFieldId];
                item.value = itemData.item[$scope.displayField];
                $scope.elements[elementId].values.push(item);
                $rootScope.loading = false;
            }
        }, function () {
            $rootScope.currentDisplayActionsMode = $scope.DisplayActionsModes.General;
        });
    };

    $scope.labelDeviceAutoComplete = {
        source: function (request, response) {
            var array = [];
            $scope.search = {};
            $scope.search[$scope.displayField] = request.term + '*';
            $scope.search[$scope.searchFieldId] = this.options.additional;

            var data = {
                controller: "ViewController",
                method: "buildList",
                countOnPage: 20,
                currentPage: 0,
                orderField: '',
                orderMethod: '',
                viewId: $scope.field.dataSource.id,
                params: $scope.search
            };

            $.post('index.php', data, function (result) {
                if (result.success) {
                    $scope.$apply(function () {
                        $.each(result.view.items, function (a, b) {
                            array.push(b);
                        });

                        response(array);
                    });
                }
            }, 'json');
        },
        minLength: 2,
        select: function (event, ui) {
            var additional = $(this).attr('additional');
            $timeout(function () {
                if ($scope.elements[additional].values == undefined)
                    $scope.elements[additional].values = [];

                if ($.grep($scope.elements[additional].values, function (n) {
                        return n.id != ui.item[$scope.IDFieldId];
                    }).length == $scope.elements[additional].values.length) {
                    var item = {};
                    item.id = ui.item[$scope.IDFieldId];
                    item.value = ui.item[$scope.displayField];
                    $scope.elements[additional].values.push(item);
                }
            });
            this.value = '';
            return false;
        },

        _renderItem: function (ul, item) {
            return $("<li>").data("item.autocomplete", item)
                .append("<a>" + item[$scope.displayField] + "</a>")
                .appendTo(ul);
        },

        focus: function (event, ui) {
            var additional = $(this).attr('additional');
            $timeout(function () {
                $scope.elements[additional].autoCompleteItem = ui.item[$scope.displayField];
            });
        }
    };

    $scope.deleteAttribute = function(elementId)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete attribute "' + $scope.elements[elementId].title + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {

                $scope.elements[elementId].values = [];
                $scope.elements[elementId].visible = false;

                Notification.info('Attribute "' + $scope.elements[elementId].title + '" was deleted!');

            });
    };

    $scope.deleteAttributeItem = function(elementId)
    {
        $uibModal.open({
            templateUrl: '/backend/webcontent/templates/objects/modal/modalWindow.html',
            controller: 'ModalWindowCtrl',
            size: 'sm',
            resolve: {
                params: function () {
                    return {
                        'msg' : 'Delete value for attribute "' + $scope.elements[elementId].title + '" ?',
                        'title' : 'Please, confirm action'
                    };
                }
            }
        }).result.then(function() {

                $.each($scope.elements[elementId].selectedItems, function(i) {
                    var selected = $scope.elements[elementId].selectedItems[i];
                    $.each($scope.elements[elementId].values, function(index)
                    {
                        if(this.id == selected)
                            $scope.elements[elementId].values.splice(index, 1);
                    })
                });
            });
    };

    $scope.getNestedAttributeValue = function(element){
        var val = '';
        if(element.dataSource[0].value) {
            $.each(element.dataSource[0].value, function(valI, value){
                switch(value.id)
                {
                    case '100000000000':
                        val = val + " " + value.value + " ";
                        break;

                    default:
                        if ($scope.elements[value.id] && $scope.elements[value.id].values && $scope.elements[value.id].values[0]) {
                            if($scope.elements[value.id].values[0].value) {
                                val = val + $scope.elements[value.id].values[0].value;
                                if (value.measure.id && value.measure.visible == 'true')
                                    val = val + " " + $scope.elements[value.id].measureTitle;
                            }
                        }
                        break;
                }
            });
        }

        return {
            id: element.dataSource[0].id,
            value: val
        };
    };
});